﻿# -*- coding: utf-8 -*-
"""
bot.py — AI Undress Bot (OFFLINE MODE + PRIORITY QUEUE)
- Priority queue: Direct image uploads > /premium > presets
- Runs completely offline - NO cloud sync
- NO server connection
- PROXY DISABLED
- Python 3.12 compatible
"""

import os
import sys
import json
import time
import random
import shutil
import re
import uuid
import hashlib
import threading
import asyncio
import logging
import tempfile
import platform
import subprocess
from datetime import datetime
from urllib.parse import urlparse, urljoin, parse_qs, unquote
from typing import Dict, Optional, Tuple, List, Any
from concurrent.futures import ThreadPoolExecutor
from enum import Enum

import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import WebDriverException

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, BotCommand, InputMediaPhoto, Chat
from telegram import BotCommandScopeAllPrivateChats, BotCommandScopeAllGroupChats
from telegram.error import BadRequest
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler,
    filters, ConversationHandler, CallbackContext,
    ApplicationHandlerStop, TypeHandler, ChatMemberHandler,
)

# ======================== CLOUDFLARE D1 CONFIG ========================

CLOUDFLARE_API_URL = "https://presetapi.contactwithzer.workers.dev"  # URL Worker của bạn
_preset_cache = None
_cache_time = 0
CACHE_TTL = 60

def load_presets_from_cloud():
    """Load presets từ Cloudflare D1"""
    global _preset_cache, _cache_time
    
    if _preset_cache and (time.time() - _cache_time < CACHE_TTL):
        return _preset_cache
    
    try:
        response = requests.get(f'{CLOUDFLARE_API_URL}/presets', timeout=5)
        if response.status_code == 200:
            data = response.json()
            if data.get('success'):
                presets = {}
                for p in data['data']:
                    key = p['key']
                    presets[key] = {
                        'name': p['name'],
                        'image': p['image'],
                        'prompt': p['prompt'],
                        'has_cum': bool(p['has_cum']),
                    }
                    if p.get('cum_prompt'):
                        presets[key]['cum_prompt'] = p['cum_prompt']
                
                _preset_cache = presets
                _cache_time = time.time()
                logger.info(f"✅ Loaded {len(presets)} presets from Cloudflare D1")
                return presets
    except Exception as e:
        logger.error(f"Cloudflare API error: {e}")
    
    return {}

def add_preset_to_cloud(key, name, image, prompt, has_cum=False, cum_prompt=None):
    """Thêm preset lên Cloudflare D1"""
    try:
        data = {
            'key': key,
            'name': name,
            'image': image,
            'prompt': prompt,
            'has_cum': has_cum
        }
        if cum_prompt:
            data['cum_prompt'] = cum_prompt
        
        response = requests.post(
            f'{CLOUDFLARE_API_URL}/presets',
            json=data,
            timeout=10
        )
        if response.status_code == 200:
            global _preset_cache, _cache_time
            _preset_cache = None
            _cache_time = 0
            logger.info(f"✅ Added preset to Cloudflare: {key}")
            return True
    except Exception as e:
        logger.error(f"Add preset to Cloudflare failed: {e}")
    return False

def delete_preset_from_cloud(key):
    """Xóa preset khỏi Cloudflare D1"""
    try:
        response = requests.delete(
            f'{CLOUDFLARE_API_URL}/presets/{key}',
            timeout=10
        )
        if response.status_code == 200:
            global _preset_cache, _cache_time
            _preset_cache = None
            _cache_time = 0
            logger.info(f"✅ Deleted preset from Cloudflare: {key}")
            return True
    except Exception as e:
        logger.error(f"Delete preset from Cloudflare failed: {e}")
    return False

# ======================== CATEGORY CLOUD FUNCTIONS ========================

_category_cache      = None
_category_cache_time = 0

def _invalidate_category_cache():
    global _category_cache, _category_cache_time
    _category_cache      = None
    _category_cache_time = 0

def load_categories_from_cloud() -> list:
    """Load categories từ Cloudflare D1. Trả về [{id, name, prompts:[{id,prompt}]}, ...]"""
    global _category_cache, _category_cache_time
    if _category_cache is not None and (time.time() - _category_cache_time < CACHE_TTL):
        return _category_cache
    try:
        response = requests.get(f'{CLOUDFLARE_API_URL}/categories', timeout=5)
        if response.status_code == 200:
            data = response.json()
            if data.get('success'):
                cats = data.get('data', [])
                _category_cache      = cats
                _category_cache_time = time.time()
                logger.info(f"✅ Loaded {len(cats)} categories from Cloudflare D1")
                return cats
    except Exception as e:
        logger.error(f"Load categories from Cloudflare failed: {e}")
    return []

def create_category_on_cloud(name: str):
    """Tạo category mới. Trả về (category_id, None) hoặc (None, error_msg)."""
    try:
        response = requests.post(
            f'{CLOUDFLARE_API_URL}/categories',
            json={'name': name},
            timeout=10
        )
        data = response.json()
        if data.get('success'):
            _invalidate_category_cache()
            cat_id = data.get('id')
            logger.info(f"✅ Created category '{name}' id={cat_id}")
            return cat_id, None
        return None, data.get('error', 'Unknown error')
    except Exception as e:
        logger.error(f"Create category failed: {e}")
        return None, str(e)

def add_prompt_to_category(cat_id, prompt: str):
    """Thêm 1 prompt vào category. Trả về (prompt_id, None) hoặc (None, error_msg)."""
    try:
        response = requests.post(
            f'{CLOUDFLARE_API_URL}/categories/{cat_id}/prompts',
            json={'prompt': prompt},
            timeout=10
        )
        data = response.json()
        if data.get('success'):
            _invalidate_category_cache()
            pid = data.get('id')
            logger.info(f"✅ Added prompt to category {cat_id}, prompt_id={pid}")
            return pid, None
        return None, data.get('error', 'Unknown error')
    except Exception as e:
        logger.error(f"Add prompt to category failed: {e}")
        return None, str(e)

def delete_category_from_cloud(cat_id):
    """Xóa category + toàn bộ prompts."""
    try:
        response = requests.delete(f'{CLOUDFLARE_API_URL}/categories/{cat_id}', timeout=10)
        if response.status_code == 200:
            _invalidate_category_cache()
            logger.info(f"✅ Deleted category id={cat_id}")
            return True
    except Exception as e:
        logger.error(f"Delete category from Cloudflare failed: {e}")
    return False

# ======================== RANDOM PROMPTS CLOUD FUNCTIONS ========================

_random_prompt_cache      = None
_random_prompt_cache_time = 0

def _invalidate_random_prompt_cache():
    global _random_prompt_cache, _random_prompt_cache_time
    _random_prompt_cache      = None
    _random_prompt_cache_time = 0

def load_random_prompts_from_cloud() -> list:
    """Load toàn bộ random prompts từ Cloudflare D1.
    Trả về list[dict] mỗi item: {id, prompt}
    """
    global _random_prompt_cache, _random_prompt_cache_time
    if _random_prompt_cache is not None and (time.time() - _random_prompt_cache_time < CACHE_TTL):
        return _random_prompt_cache
    try:
        response = requests.get(f'{CLOUDFLARE_API_URL}/random-prompts', timeout=5)
        if response.status_code == 200:
            data = response.json()
            if data.get('success'):
                prompts = data.get('data', [])
                _random_prompt_cache      = prompts
                _random_prompt_cache_time = time.time()
                logger.info(f"✅ Loaded {len(prompts)} random prompts from Cloudflare D1")
                return prompts
    except Exception as e:
        logger.error(f"Load random prompts from Cloudflare failed: {e}")
    return []

def add_random_prompts_to_cloud(prompts: list) -> tuple:
    """Thêm nhiều prompts vào bảng random_prompts.
    prompts: list[str]
    Trả về (added_count, failed_count)
    """
    added, failed = 0, 0
    for p in prompts:
        p = p.strip()
        if not p:
            continue
        try:
            response = requests.post(
                f'{CLOUDFLARE_API_URL}/random-prompts',
                json={'prompt': p},
                timeout=10
            )
            data = response.json()
            if data.get('success'):
                added += 1
            else:
                failed += 1
        except Exception as e:
            logger.error(f"Add random prompt failed: {e}")
            failed += 1
    if added > 0:
        _invalidate_random_prompt_cache()
    return added, failed

def delete_random_prompt_from_cloud(prompt_id) -> bool:
    """Xóa 1 random prompt theo id."""
    try:
        response = requests.delete(
            f'{CLOUDFLARE_API_URL}/random-prompts/{prompt_id}',
            timeout=10
        )
        if response.status_code == 200:
            _invalidate_random_prompt_cache()
            logger.info(f"✅ Deleted random prompt id={prompt_id}")
            return True
    except Exception as e:
        logger.error(f"Delete random prompt from Cloudflare failed: {e}")
    return False

def get_one_random_prompt() -> Optional[dict]:
    """Lấy 1 prompt ngẫu nhiên từ cloud. Trả về {id, prompt} hoặc None."""
    prompts = load_random_prompts_from_cloud()
    if not prompts:
        return None
    return random.choice(prompts)

def get_random_prompts(n: int) -> list:
    """Lấy n prompt ngẫu nhiên KHÔNG trùng nhau từ cloud.
    Nếu pool ít hơn n thì lấy tất cả rồi shuffle.
    Trả về list[dict] mỗi item: {id, prompt}
    """
    prompts = load_random_prompts_from_cloud()
    if not prompts:
        return []
    if len(prompts) <= n:
        result = prompts[:]
        random.shuffle(result)
        return result
    return random.sample(prompts, n)

# ======================== PRIORITY ENUM ========================

class JobPriority(Enum):
    """Job priority levels"""
    HIGH = 0      # Direct image uploads (User sends photo + prompt)
    MEDIUM = 1    # Selected presets (User selects & generates)
    LOW = 2       # Premium mode (All presets)

# ======================== PROXY DISABLED ========================

PROXY_ENABLED = False
PROXY_CONFIG = {}

# ======================== GLOBAL STATE ========================

user_sessions = {}
pending_jobs  = {}

# ======================== AUTO-DELETE UTILITY ========================

AUTO_DELETE_DELAY = 30   # giây — xóa tin nhắn tạm sau khoảng này

async def _delete_after(bot, chat_id: int, message_id: int, delay: int = AUTO_DELETE_DELAY):
    """Xóa 1 tin nhắn sau `delay` giây. Chạy nền, không block."""
    await asyncio.sleep(delay)
    try:
        await bot.delete_message(chat_id=chat_id, message_id=message_id)
    except Exception:
        pass   # Tin nhắn đã xóa hoặc bot không có quyền — bỏ qua

def schedule_delete(bot, chat_id: int, message_id: int, delay: int = AUTO_DELETE_DELAY):
    """Lên lịch xóa tin nhắn không đồng bộ (fire-and-forget)."""
    asyncio.create_task(_delete_after(bot, chat_id, message_id, delay))

# --- Bot Token (ưu tiên biến môi trường khi deploy) ---
TELEGRAM_TOKEN = (
    os.environ.get("TELEGRAM_BOT_TOKEN")
    or os.environ.get("TELEGRAM_TOKEN")
    or "8829237678:AAFQH9bItnDBE5gzUz2zqspD0TycTjGYFLY"
)

# --- Local Paths ---
BASE_DIR = os.path.join(os.path.expanduser("~"), "telegram-bot-data")
if platform.system() == "Windows":
    BASE_DIR = r"C:\Users\Administrator\telegram-bot-data"

TEMP_DIR = os.path.join(BASE_DIR, "temp")
DOWN_DIR = os.path.join(BASE_DIR, "down")
PRESETS_FILE = os.path.join(BASE_DIR, "presets.json")
ACCOUNTS_FILE = os.path.join(BASE_DIR, "accounts.txt")
SYNC_LOG = os.path.join(BASE_DIR, "sync.log")

# --- Chrome ---
MAX_CHROME_TABS = 1
CHROME_HEADLESS = False

# --- Target Site ---
SIGNUP_URL      = "https://ai-undress.ai/vi/auth/signup"
CREATIONS_URL   = "https://ai-undress.ai/vi/my/creations"
RESULT_CHANNEL_ID = -1003949788309

# --- S2 Album API ---
S2_API_BASE   = "https://eter.qzz.io/s2/api"   # base URL của s2 API
S2_ALBUM_VIEW = "https://eter.qzz.io/s2/album.php"  # link xem album
S2_CDN_BASE   = "https://cdn.eawara.fun"         # CDN public

# --- Mail ---
MAILTM_API = "https://api.mail.tm"
GUERRILLA_API = "https://api.guerrillamail.com/ajax.php"
MAILTM_FAIL_BEFORE_FALLBACK = 5

# ⚡ EMAIL POLLING OPTIMIZATION
EMAIL_POLL_INTERVAL = 0.5   # Poll mỗi 0.5s (4x nhanh hơn default)
EMAIL_POLL_TIMEOUT  = 60    # Timeout 60s
EMAIL_POLL_THREADS  = 3     # Số luồng song song
MAX_RETRIES_EMAIL   = 120   # 60s / 0.5s

# --- Admin IDs ---
ADMIN_IDS = set()

# --- Chat access (groups blocked unless whitelisted) ---
ALLOW_PRIVATE_CHATS = True
# Thêm chat_id nhóm (số âm) nếu muốn cho phép 1 nhóm cụ thể; mặc định rỗng = cấm mọi nhóm
ALLOWED_GROUP_IDS = frozenset()
_group_leave_done = set()

def is_chat_allowed(chat) -> bool:
    if chat is None:
        return False
    if chat.type == Chat.PRIVATE:
        return ALLOW_PRIVATE_CHATS
    if chat.type in (Chat.GROUP, Chat.SUPERGROUP):
        return chat.id in ALLOWED_GROUP_IDS
    return False

async def enforce_private_only(update: Update, context: CallbackContext):
    """Chặn lệnh / tag / callback trong nhóm (trừ nhóm whitelist)."""
    if update.my_chat_member is not None:
        return
    chat = update.effective_chat
    if is_chat_allowed(chat):
        return
    if chat and chat.type in (Chat.GROUP, Chat.SUPERGROUP):
        cid = chat.id
        if cid not in _group_leave_done:
            _group_leave_done.add(cid)
            try:
                if update.effective_message:
                    await update.effective_message.reply_text(
                        "⛔ Bot chỉ hoạt động trong chat riêng (DM).\n"
                        "Vui lòng mở bot và bấm Start."
                    )
            except Exception:
                pass
            try:
                await context.bot.leave_chat(cid)
                logger.info(f"Left unauthorized group {cid}")
            except Exception as e:
                logger.warning(f"Could not leave group {cid}: {e}")
    raise ApplicationHandlerStop

async def on_bot_added_to_chat(update: Update, context: CallbackContext):
    """Tự rời nhóm nếu bị thêm vào nhóm không được phép."""
    if not update.my_chat_member:
        return
    chat = update.my_chat_member.chat
    member = update.my_chat_member.new_chat_member
    if member.user.id != context.bot.id:
        return
    if member.status not in ("member", "administrator", "restricted"):
        return
    if chat.type not in (Chat.GROUP, Chat.SUPERGROUP):
        return
    if chat.id in ALLOWED_GROUP_IDS:
        return
    try:
        await context.bot.leave_chat(chat.id)
        logger.info(f"Auto-left unauthorized group {chat.id} ({chat.title})")
    except Exception as e:
        logger.warning(f"Auto-leave failed for {chat.id}: {e}")

# --- Conversation States ---
(STATE_NAME, STATE_IMAGE, STATE_PROMPT, STATE_HAS_CUM, STATE_CUM_PROMPT,
 STATE_CUSTOM_PROMPT, STATE_CUSTOM_IMAGE,
 STATE_CAT_NAME, STATE_CAT_PROMPT,
 STATE_RANDOM_ADD, STATE_RANDOM_DEL) = range(11)

# --- Progress stages ---
PROGRESS = {
    "creating_email": (5, "📧 Tạo email..."),
    "opening_signup": (10, "🔗 Mở signup..."),
    "waiting_confirm": (15, "⏳ Chờ xác nhận email..."),
    "logging_in": (25, "🔐 Đăng nhập..."),
    "uploading": (35, "📤 Upload ảnh..."),
    "prompt": (45, "📝 Nhập prompt..."),
    "generating": (60, "🎨 Đang sinh..."),
    "gallery_fallback": (70, "📸 Kiểm tra thư viện..."),
    "downloading": (85, "⬇️ Tải ảnh..."),
    "done": (100, "✅ Hoàn tất!")
}

# ======================== PRESETS FROM CLOUDFLARE D1 ========================

# Presets are now loaded from Cloudflare D1 via load_presets_from_cloud()
# No hardcoded defaults - always fetch from database

# ======================== SETUP ========================

os.makedirs(BASE_DIR, exist_ok=True)
os.makedirs(TEMP_DIR, exist_ok=True)
os.makedirs(DOWN_DIR, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(SYNC_LOG, encoding="utf-8")
    ]
)
logger = logging.getLogger(__name__)

# Suppress spam
for spam in ["httpx", "telegram.ext", "urllib3", "selenium", "urllib3.connectionpool"]:
    logging.getLogger(spam).setLevel(logging.WARNING)

# ======================== PROCESS PRIORITY & CPU AFFINITY ========================

def _boost_process():
    """
    Đặt tiến trình Python lên High Priority và gán toàn bộ CPU cores.
    Chạy một lần khi khởi động — dồn tài nguyên máy cho bot.
    """
    pid = os.getpid()
    cpu_count = os.cpu_count() or 1
    if platform.system() == "Windows":
        try:
            import ctypes
            handle = ctypes.windll.kernel32.OpenProcess(0x1F0FFF, False, pid)
            ctypes.windll.kernel32.SetPriorityClass(handle, 0x80)   # HIGH
            ctypes.windll.kernel32.CloseHandle(handle)
            logger.info("⚡ Process priority: HIGH")
        except Exception as e:
            logger.warning("Priority set failed: %s", e)
        try:
            import ctypes
            mask = (1 << cpu_count) - 1
            handle = ctypes.windll.kernel32.OpenProcess(0x1F0FFF, False, pid)
            ctypes.windll.kernel32.SetProcessAffinityMask(handle, mask)
            ctypes.windll.kernel32.CloseHandle(handle)
            logger.info("⚡ CPU affinity: all %d cores", cpu_count)
        except Exception as e:
            logger.warning("Affinity set failed: %s", e)
    else:
        try:
            os.nice(-10)
        except Exception:
            pass
        try:
            import psutil
            psutil.Process(pid).cpu_affinity(list(range(cpu_count)))
        except Exception:
            pass
    import gc
    gc.set_threshold(10000, 200, 100)
    logger.info("⚡ GC threshold: 10000/200/100")

_boost_process()

# ======================== CLOUD SYNC (DISABLED) ========================

class CloudSync:
    @classmethod
    def health(cls): return False
    @classmethod
    def download(cls, name, save_path): return False
    @classmethod
    def upload(cls, name, file_path): return False
    @classmethod
    def get_server_hashes(cls): return {}
    @classmethod
    def initial_sync(cls): 
        logger.info("=== Cloud sync DISABLED ===")
        return False
    @classmethod
    def start_watcher(cls): pass

# ======================== PRESETS MANAGEMENT ========================

def load_presets():
    """Load presets từ Cloudflare D1, fallback to local file nếu API lỗi"""
    # Thử load từ Cloudflare D1 trước
    presets = load_presets_from_cloud()
    
    if presets:
        return presets
    
    # Fallback: load từ local file nếu cloud không available
    if os.path.exists(PRESETS_FILE):
        try:
            with open(PRESETS_FILE, 'r', encoding='utf-8') as f:
                logger.warning("⚠️ Cloudflare API unavailable, using local presets cache")
                return json.load(f)
        except Exception as e:
            logger.error("Load presets from file failed: %s", e)
    
    logger.warning("⚠️ No presets available from Cloudflare or local file")
    return {}

def save_presets(presets):
    """Save presets to local file"""
    try:
        with open(PRESETS_FILE, 'w', encoding='utf-8') as f:
            json.dump(presets, f, ensure_ascii=False, indent=2)
        logger.info("💾 Presets saved locally to %s", PRESETS_FILE)
    except Exception as e:
        logger.error("Save presets failed: %s", e)

async def sync_presets_to_telegram(bot):
    """Send presets file to Telegram channel for backup"""
    try:
        if os.path.exists(PRESETS_FILE):
            with open(PRESETS_FILE, 'rb') as f:
                await bot.send_document(
                    chat_id=RESULT_CHANNEL_ID,
                    document=f,
                    caption=f"📋 Presets backup - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n🔄 Auto-sync on code update"
                )
            logger.info("📤 Presets synced to Telegram channel")
    except Exception as e:
        logger.error("Failed to sync presets to Telegram: %s", e)

PRESETS = load_presets()

# ======================== PRIORITY JOB QUEUE ========================

class PriorityJob:
    """Job với priority"""
    def __init__(self, data: dict, priority: JobPriority):
        self.data = data
        self.priority = priority
        self.timestamp = time.time()
    
    def __lt__(self, other):
        """So sánh: priority thấp hơn được xử lý trước"""
        if self.priority.value != other.priority.value:
            return self.priority.value < other.priority.value
        # Nếu priority bằng nhau, theo thứ tự FIFO
        return self.timestamp < other.timestamp

# ======================== STEALTH & ANTI-DETECTION ========================
# Cloudflare Turnstile phân tích: navigator.webdriver, canvas fingerprint,
# mouse entropy, keyboard timing, WebGL, plugins. Cần giả lập tất cả.

# Rotate User-Agent — chỉ dùng real Chrome trên Windows 10/11
_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36",
]

def _random_ua() -> str:
    return random.choice(_USER_AGENTS)

# JS chạy trước mọi script của trang — cấu hình chuẩn Chrome người dùng thật
_STEALTH_JS = """
// 1. Xóa navigator.webdriver triệt để
try {
    delete Object.getPrototypeOf(navigator).webdriver;
} catch(e) {}
Object.defineProperty(navigator, 'webdriver', {
    get: () => undefined,
    configurable: true
});

// 2. Fake Chrome Runtime đầy đủ như Chrome người dùng thật
if (!window.chrome) {
    window.chrome = {};
}
window.chrome.runtime = {
    PlatformOs: { MAC: 'mac', WIN: 'win', ANDROID: 'android', CROS: 'cros', LINUX: 'linux', OPENBSD: 'openbsd' },
    PlatformArch: { ARM: 'arm', X86_32: 'x86-32', X86_64: 'x86-64' },
    PlatformNaclArch: { ARM: 'arm', X86_32: 'x86-32', X86_64: 'x86-64' },
    RequestUpdateCheckStatus: { THROTTLED: 'throttled', NO_UPDATE: 'no_update', UPDATE_AVAILABLE: 'update_available' },
    OnInstalledReason: { INSTALL: 'install', UPDATE: 'update', CHROME_UPDATE: 'chrome_update', SHARED_MODULE_UPDATE: 'shared_module_update' },
    OnRestartRequiredReason: { APP_UPDATE: 'app_update', OS_UPDATE: 'os_update', PERIODIC: 'periodic' },
    connect: function() {},
    sendMessage: function() {},
    onMessage: { addListener: function() {}, removeListener: function() {} }
};
window.chrome.loadTimes = function() {
    return {
        requestTime: (Date.now() - 3200) / 1000,
        startLoadTime: (Date.now() - 3000) / 1000,
        commitLoadTime: (Date.now() - 2600) / 1000,
        finishDocumentLoadTime: (Date.now() - 1100) / 1000,
        finishLoadTime: (Date.now() - 600) / 1000,
        firstPaintTime: (Date.now() - 1300) / 1000,
        firstPaintAfterLoadTime: 0,
        navigationType: 'Other'
    };
};
window.chrome.csi = function() {
    return {
        startE: Date.now() - 3200,
        onloadT: Date.now() - 600,
        pageT: 2600,
        tran: 15
    };
};
window.chrome.app = {
    isInstalled: false,
    InstallState: { DISABLED: 'disabled', INSTALLED: 'installed', NOT_INSTALLED: 'not_installed' },
    RunningState: { CANNOT_RUN: 'cannot_run', READY_TO_RUN: 'ready_to_run', RUNNING: 'running' },
    getIsInstalled: function() { return false; },
    getDetails: function() { return null; },
    getInstallState: function(cb) { if (cb) cb('not_installed'); }
};

// 3. Xóa cdc_ và các thuộc tính tự sinh của chromedriver
const cdc_keys = Object.keys(window).filter(k => k.startsWith('cdc_') || k.startsWith('__$cdc'));
cdc_keys.forEach(k => { try { delete window[k]; } catch(e){} });

// 4. Fake languages & platform chuẩn máy Windows
Object.defineProperty(navigator, 'languages', {get: () => ['vi-VN', 'vi', 'en-US', 'en']});
Object.defineProperty(navigator, 'language', {get: () => 'vi-VN'});
Object.defineProperty(navigator, 'platform', {get: () => 'Win32'});
Object.defineProperty(navigator, 'hardwareConcurrency', {get: () => 8});
Object.defineProperty(navigator, 'deviceMemory', {get: () => 8});

// 5. Fake plugins chuẩn Chrome thật
if (!navigator.plugins || navigator.plugins.length === 0) {
    const makePlugin = (name, filename, desc) => {
        const p = { name, filename, description: desc, length: 1 };
        p[0] = { type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: p };
        return p;
    };
    const pluginsArr = [
        makePlugin('PDF Viewer', 'internal-pdf-viewer', 'Portable Document Format'),
        makePlugin('Chrome PDF Viewer', 'internal-pdf-viewer', 'Portable Document Format'),
        makePlugin('Chromium PDF Viewer', 'internal-pdf-viewer', 'Portable Document Format'),
        makePlugin('Microsoft Edge PDF Viewer', 'internal-pdf-viewer', 'Portable Document Format'),
        makePlugin('WebKit built-in PDF', 'internal-pdf-viewer', 'Portable Document Format')
    ];
    Object.defineProperty(navigator, 'plugins', { get: () => pluginsArr });
}

// 6. Fake WebGL unmasked vendor & renderer (GPU NVIDIA trên Windows)
const getParameter = WebGLRenderingContext.prototype.getParameter;
WebGLRenderingContext.prototype.getParameter = function(parameter) {
    if (parameter === 37445) return 'Google Inc. (NVIDIA)';
    if (parameter === 37446) return 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)';
    return getParameter.apply(this, [parameter]);
};
if (typeof WebGL2RenderingContext !== 'undefined') {
    const getParameter2 = WebGL2RenderingContext.prototype.getParameter;
    WebGL2RenderingContext.prototype.getParameter = function(parameter) {
        if (parameter === 37445) return 'Google Inc. (NVIDIA)';
        if (parameter === 37446) return 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)';
        return getParameter2.apply(this, [parameter]);
    };
}

// 7. Fake screen dimensions chuẩn desktop 1080p
Object.defineProperty(screen, 'width', {get: () => 1920});
Object.defineProperty(screen, 'height', {get: () => 1080});
Object.defineProperty(screen, 'availWidth', {get: () => 1920});
Object.defineProperty(screen, 'availHeight', {get: () => 1040});
Object.defineProperty(screen, 'colorDepth', {get: () => 24});
Object.defineProperty(screen, 'pixelDepth', {get: () => 24});

// 8. Permission API chuẩn
const origQuery = window.navigator.permissions.query.bind(window.navigator.permissions);
window.navigator.permissions.query = (params) => {
    if (params && params.name === 'notifications') {
        return Promise.resolve({
            state: Notification.permission === 'granted' ? 'granted' : (Notification.permission === 'denied' ? 'denied' : 'prompt'),
            name: 'notifications',
            onchange: null
        });
    }
    return origQuery(params);
};

// 9. Connection API
if (!navigator.connection) {
    Object.defineProperty(navigator, 'connection', {
        get: () => ({
            rtt: 50,
            downlink: 10,
            effectiveType: '4g',
            saveData: false,
            onchange: null
        })
    });
}
"""


def _stealth_patch(driver):
    """Inject stealth JS qua CDP — chạy trước mọi script của trang."""
    try:
        driver.execute_cdp_cmd(
            "Page.addScriptToEvaluateOnNewDocument",
            {"source": _STEALTH_JS}
        )
        logger.debug("[STEALTH] CDP stealth patch applied")
    except Exception as e:
        logger.warning("[STEALTH] CDP patch failed: %s", e)
        # Fallback: inject trực tiếp
        try:
            driver.execute_script(_STEALTH_JS)
        except Exception:
            pass

# ======================== CHROME DRIVER ========================

def get_chrome_driver():
    """Tạo Chrome driver với anti-detection — dựa trên config đã bypass Turnstile."""
    ua = _random_ua()
    options = webdriver.ChromeOptions()

    # ── Window size — KHÔNG dùng --start-maximized cùng lúc (conflict) ──
    options.add_argument("--window-size=1920,1080")

    # ── User-Agent — dùng đúng UA của Chrome version đang chạy ──────────
    # KHÔNG override UA custom vì Turnstile cross-check UA vs JS APIs
    # Chỉ override nếu cần thiết
    # options.add_argument(f"--user-agent={ua}")

    # ── Sandbox / system ──────────────────────────────────────────────────
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")

    # ── KHÔNG disable GPU/WebGL/Canvas — Turnstile dùng để fingerprint ──
    # options.add_argument("--disable-gpu")             ← BỎ
    # options.add_argument("--disable-webgl")           ← BỎ
    # options.add_argument("--disable-accelerated-2d-canvas")  ← BỎ
    # options.add_argument("--disable-software-rasterizer")    ← BỎ

    # ── Cấu hình trình duyệt chuẩn như người dùng thật ────────────────────
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-infobars")
    options.add_argument("--no-first-run")
    options.add_argument("--no-default-browser-check")
    options.add_argument("--remote-allow-origins=*")
    options.add_argument("--mute-audio")
    options.add_argument("--lang=vi-VN,vi,en-US,en")

    # ── Anti-detection cốt lõi ────────────────────────────────────────────
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation", "enable-logging"])
    options.add_experimental_option("useAutomationExtension", False)

    # ── Prefs: tắt password save, notification popup, set language ────────
    prefs = {
        "credentials_enable_service": False,
        "profile.password_manager_enabled": False,
        "profile.default_content_setting_values.notifications": 2,
        "intl.accept_languages": "vi-VN,vi,en-US,en",
    }
    options.add_experimental_option("prefs", prefs)

    # ── eager: không chờ ảnh/font load — Turnstile script vẫn chạy đủ ──
    # Dùng "normal" thay "eager" — tránh abort sớm trước khi JS hydrate xong
    options.page_load_strategy = "normal"

    # Cách 1: Selenium Manager
    try:
        driver = webdriver.Chrome(options=options)
        return driver
    except Exception as e:
        logger.warning("Selenium Manager failed: %s", e)

    # Cách 2: webdriver-manager
    try:
        from webdriver_manager.chrome import ChromeDriverManager
        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=options)
        return driver
    except Exception as e:
        logger.warning("webdriver-manager failed: %s", e)

    # Cách 3: thủ công
    for path in [
        os.path.join(os.path.dirname(__file__), "chromedriver.exe"),
        "C:\\Windows\\System32\\chromedriver.exe",
        "C:\\WebDriver\\chromedriver.exe",
        os.path.join(os.getcwd(), "chromedriver.exe"),
    ]:
        if os.path.exists(path):
            try:
                driver = webdriver.Chrome(service=Service(executable_path=path), options=options)
                return driver
            except Exception as e:
                logger.warning("Manual driver %s failed: %s", path, e)

    raise Exception("Không tìm thấy ChromeDriver!")

def create_driver():
    """Tạo driver với stealth patch, retry tự động."""
    # Dùng resolution phổ biến, thêm variance nhỏ để không giống nhau 100%
    w = random.choice([1920, 1440, 1366, 1280])
    h = {1920: 1080, 1440: 900, 1366: 768, 1280: 800}[w]

    for attempt in range(1, 6):
        try:
            driver = get_chrome_driver()
            driver.set_page_load_timeout(120)
            driver.set_script_timeout(60)
            driver.set_window_size(w, h)
            driver.implicitly_wait(3)   # nhỏ hơn để không block quá lâu

            # ── Inject stealth trước khi bất kỳ page nào load ────────
            _stealth_patch(driver)

            # ── Navigate về about:blank để thoát data:, rồi sẵn sàng ──
            try:
                if "data:" in (driver.current_url or ""):
                    driver.get("about:blank")
                    time.sleep(0.3)
            except Exception:
                pass

            logger.info("✅ Driver ready (attempt %d, %dx%d)", attempt, w, h)
            return driver
        except Exception as e:
            logger.error("Driver init attempt %d: %s", attempt, e)
            if attempt < 5:
                time.sleep(2 + random.uniform(0, 2))
            else:
                raise

def is_alive(driver):
    if driver is None:
        return False
    try:
        driver.execute_script("return 1")
        return True
    except Exception:
        return False

def safe_quit(driver):
    if driver:
        try:
            driver.quit()
        except Exception:
            pass

# ======================== MAIL ========================

_mailtm_fail = 0

def _parse_hydra(data):
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for k in ("hydra:member", "member", "items", "data"):
            if isinstance(data.get(k), list):
                return data[k]
        if data.get("domain") or data.get("id"):
            return [data]
    return []

def mail_req(method, path, api_base, json_data=None, token=None):
    h = {"Accept": "application/json", "Content-Type": "application/json", "User-Agent": "Bot/1.0"}
    if token:
        h["Authorization"] = "Bearer " + token
    return requests.request(method, api_base.rstrip("/") + path, json=json_data, headers=h, timeout=30)

def mail_create(api_base):
    for _ in range(8):
        try:
            r = mail_req("GET", "/domains", api_base)
            if r.status_code == 429:
                time.sleep(5)
                continue
            if r.status_code != 200:
                time.sleep(2)
                continue
            domains = _parse_hydra(r.json())
            domain = next((d.get("domain") or d.get("name") for d in domains if "." in (d.get("domain") or "")), None)
            if not domain:
                continue

            local = "".join(random.choice("abcdefghijklmnopqrstuvwxyz0123456789") for _ in range(random.randint(10, 14)))
            email = f"{local}@{domain}"
            pwd = "".join(random.choice("abcdefghijklmnopqrstuvwxyz0123456789") for _ in range(12))

            r = mail_req("POST", "/accounts", api_base, {"address": email, "password": pwd})
            if r.status_code not in (201, 422):
                if r.status_code == 429:
                    time.sleep(5)
                continue

            r = mail_req("POST", "/token", api_base, {"address": email, "password": pwd})
            if r.status_code == 200:
                token = r.json().get("token") or r.json().get("accessToken")
                if token:
                    logger.info("[MAILTM] Created: %s", email)
                    return {"provider": "mailtm", "email": email, "password": pwd, "token": token, "api_base": api_base}
        except Exception:
            pass
        time.sleep(2)
    return None

def guerrilla_create():
    try:
        r = requests.get(GUERRILLA_API, params={"f": "get_email_address", "lang": "en"}, timeout=30)
        if r.status_code == 200:
            d = r.json()
            email, sid = d.get("email_addr") or d.get("email"), d.get("sid_token")
            if email and sid:
                logger.info("[GUERRILLA] Created: %s", email)
                return {"provider": "guerrilla", "email": email, "password": email, "sid_token": sid}
    except Exception:
        pass
    return None

def create_temp_mail():
    global _mailtm_fail
    attempt = 0
    while True:
        attempt += 1
        if _mailtm_fail < MAILTM_FAIL_BEFORE_FALLBACK:
            auth = mail_create(MAILTM_API)
            if auth:
                _mailtm_fail = 0
                return auth["email"], auth, auth["password"]
            _mailtm_fail += 1
            logger.warning("Mail.tm fail %d/%d", _mailtm_fail, MAILTM_FAIL_BEFORE_FALLBACK)
            if _mailtm_fail < MAILTM_FAIL_BEFORE_FALLBACK:
                time.sleep(min(attempt * 2, 20))
                continue
            logger.info("Fallback to Guerrilla")
        auth = guerrilla_create()
        if auth:
            return auth["email"], auth, auth["password"]
        _mailtm_fail = 0
        time.sleep(min(attempt * 2, 30))

def _extract_links(body):
    if not body:
        return []
    links = re.findall(r"https?://[^\s\"\'<>\{\}\[\]\\|^`\n\r]+", str(body))
    return [l.rstrip(".,;)\"'") for l in links if any(k in l.lower() for k in ("confirm", "verify", "activate"))]

def wait_confirm_guerrilla(auth):
    """
    Poll hộp thư Guerrilla Mail liên tục để lấy link xác nhận.
    - Tăng seq mỗi lần để API thực sự refresh inbox (không đọc cache cũ)
    - Interval: 1.5s trong 60 poll đầu, sau đó 3s
    - Log tiến trình mỗi 10 poll
    """
    sid = auth.get("sid_token")
    if not sid:
        return None

    last = set()
    seq = 0

    for poll in range(1, 10000):
        try:
            r = requests.get(
                GUERRILLA_API,
                params={"f": "check_email", "sid_token": sid, "seq": seq},
                timeout=30
            )
            if r.status_code != 200:
                time.sleep(2)
                continue

            data = r.json()
            # Tăng seq theo giá trị server trả về (nếu có) để inbox luôn được refresh
            server_seq = data.get("seq")
            if server_seq is not None:
                seq = int(server_seq)
            else:
                seq += 1

            mail_list = data.get("list") or _parse_hydra(data)
            for item in mail_list:
                if not isinstance(item, dict):
                    continue
                mid = item.get("mail_id")
                if not mid or mid in last:
                    continue
                last.add(mid)
                # Fetch nội dung mail đầy đủ
                d = requests.get(
                    GUERRILLA_API,
                    params={"f": "fetch_email", "email_id": mid, "sid_token": sid},
                    timeout=30
                )
                if d.status_code == 200:
                    m = d.json()
                    body = " ".join(filter(None, [
                        m.get("mail_subject"),
                        m.get("mail_body"),
                        m.get("mail_excerpt")
                    ]))
                    links = _extract_links(body)
                    if links:
                        logger.info("[GUERRILLA] ✅ Confirm link found after %d polls", poll)
                        return links[0]

            if poll % 10 == 0:
                logger.info("[GUERRILLA] Waiting for mail... poll=%d seq=%d", poll, seq)

        except Exception as e:
            logger.debug("[GUERRILLA] Poll error: %s", e)

        # Interval thích nghi: nhanh lúc đầu, chậm dần
        time.sleep(1.5 if poll <= 60 else 3)

    return None

def wait_confirm_hydra(auth):
    """
    Poll hộp thư Mail.tm (hoặc provider tương tự) để lấy link xác nhận.
    - Interval: 1s trong 30 poll đầu (~30s), 2s trong 30 poll tiếp (~60s), sau đó 3s
    - Tự động refresh token khi 401 hoặc định kỳ mỗi 50 poll
    - Log tiến trình mỗi 10 poll
    - Không giới hạn số lần thử
    """
    email = auth["email"]
    pwd = auth["password"]
    api_base = auth["api_base"]
    provider = auth["provider"]
    token = auth["token"]
    last = set()
    poll = 0
    last_token_refresh = 0  # poll count khi refresh token lần cuối

    while True:
        poll += 1

        # Chủ động refresh token định kỳ mỗi 50 poll để tránh hết hạn
        if poll - last_token_refresh >= 50 and poll > 1:
            try:
                t = mail_req("POST", "/token", api_base, {"address": email, "password": pwd})
                if t.status_code == 200:
                    new_token = t.json().get("token") or t.json().get("accessToken")
                    if new_token:
                        token = new_token
                        auth["token"] = token
                        last_token_refresh = poll
                        logger.debug("[%s] Token refreshed at poll=%d", provider, poll)
            except Exception:
                pass

        try:
            r = mail_req("GET", "/messages", api_base, token=token)

            if r.status_code == 401:
                # Token hết hạn — refresh ngay
                logger.info("[%s] Token expired, refreshing...", provider)
                t = mail_req("POST", "/token", api_base, {"address": email, "password": pwd})
                if t.status_code == 200:
                    new_token = t.json().get("token") or t.json().get("accessToken")
                    if new_token:
                        token = new_token
                        auth["token"] = token
                        last_token_refresh = poll
                time.sleep(1)
                continue

            if r.status_code == 429:
                # Rate limit — chờ lâu hơn
                logger.warning("[%s] Rate limited, waiting 10s...", provider)
                time.sleep(10)
                continue

            if r.status_code != 200:
                time.sleep(2)
                continue

            for msg in _parse_hydra(r.json()):
                if not isinstance(msg, dict):
                    continue
                mid = msg.get("id")
                if not mid or mid in last:
                    continue
                last.add(mid)

                d = mail_req("GET", f"/messages/{mid}", api_base, token=token)
                if d.status_code != 200:
                    continue

                detail = d.json()
                body = ""
                for parts in (detail.get("html"), detail.get("text")):
                    if parts and isinstance(parts, list) and len(parts) > 0:
                        body = parts[0] if isinstance(parts[0], str) else str(parts[0])
                        break
                body = body or detail.get("intro", "") or detail.get("subject", "")
                links = _extract_links(body)
                if links:
                    logger.info("[%s] ✅ Confirm link found after %d polls", provider, poll)
                    return links[0]

        except Exception as e:
            logger.debug("[%s] Poll error: %s", provider, e)

        if poll % 10 == 0:
            logger.info("[%s] Waiting for mail... poll=%d", provider, poll)

        # Interval thích nghi: 1s (30 đầu) → 2s (30-60) → 3s (sau 60)
        if poll <= 30:
            time.sleep(1)
        elif poll <= 60:
            time.sleep(2)
        else:
            time.sleep(3)

def wait_confirm(auth):
    if not isinstance(auth, dict):
        return None
    return wait_confirm_guerrilla(auth) if auth.get("provider") == "guerrilla" else wait_confirm_hydra(auth)

# ======================== SITE AUTOMATION ========================
# Human simulation — tất cả tương tác đều qua các hàm này
# để Cloudflare Turnstile không phát hiện robot

def _rand(lo: float, hi: float) -> float:
    """Random float với gaussian noise — tự nhiên hơn uniform."""
    return max(lo, min(hi, random.gauss((lo + hi) / 2, (hi - lo) / 6)))


def _jitter_move(driver, element):
    """
    Di chuyển chuột tự nhiên tới element và tạo micro-jitter nhẹ như tay người thật.
    """
    try:
        from selenium.webdriver.common.action_chains import ActionChains
        ac = ActionChains(driver)
        ac.move_to_element(element)
        ac.pause(_rand(0.1, 0.25))
        # Rung chuột nhẹ vài pixel xung quanh tâm nút (micro-movements)
        dx = random.randint(-4, 4)
        dy = random.randint(-4, 4)
        ac.move_by_offset(dx, dy)
        ac.pause(_rand(0.04, 0.1))
        ac.move_by_offset(-dx, -dy)
        ac.pause(_rand(0.06, 0.15))
        ac.perform()
    except Exception as e:
        logger.debug("[HUMAN] jitter_move fallback: %s", e)
        try:
            ActionChains(driver).move_to_element(element).pause(0.2).perform()
        except Exception:
            pass


def _human_click(driver, element):
    """
    Click tự nhiên như người dùng thật: cuộn vào tầm mắt → di chuột → hover ngẫm nghĩ → click → nhả.
    """
    try:
        from selenium.webdriver.common.action_chains import ActionChains
        driver.execute_script(
            "arguments[0].scrollIntoView({block:'center', behavior:'smooth'});", element
        )
        time.sleep(_rand(0.4, 0.8))

        _jitter_move(driver, element)

        # Hover ngẫm nghĩ trước khi click
        time.sleep(_rand(0.2, 0.45))

        ac = ActionChains(driver)
        ac.move_to_element(element)
        ac.pause(_rand(0.08, 0.18))
        ac.click()
        ac.pause(_rand(0.08, 0.15))
        ac.perform()
        logger.debug("[HUMAN] human_click done")
    except Exception as e:
        logger.debug("[HUMAN] human_click failed: %s — fallback to .click()", e)
        try:
            element.click()
        except Exception:
            driver.execute_script("arguments[0].click();", element)


def _human_type(driver, element, text: str, clear: bool = True):
    """
    Gõ phím tự nhiên:
    - Click focus vào trường
    - Random delay từng phím (70-170ms)
    - Tần suất dừng ngẫu nhiên như đang nhớ mật khẩu/email
    """
    from selenium.webdriver.common.keys import Keys

    _human_click(driver, element)
    time.sleep(_rand(0.25, 0.5))

    if clear:
        element.send_keys(Keys.CONTROL + "a")
        time.sleep(_rand(0.08, 0.15))
        element.send_keys(Keys.DELETE)
        time.sleep(_rand(0.08, 0.15))

    for i, ch in enumerate(text):
        element.send_keys(ch)
        delay = _rand(0.07, 0.17)
        if random.random() < 0.07 and i > 2:
            delay += _rand(0.25, 0.6)
        time.sleep(delay)

    driver.execute_script(
        "arguments[0].dispatchEvent(new Event('input',{bubbles:true}));"
        "arguments[0].dispatchEvent(new Event('change',{bubbles:true}));",
        element
    )
    time.sleep(_rand(0.25, 0.5))


def _human_scroll(driver, distance: int = None):
    """Scroll trang nhẹ nhàng — tạo mouse activity trước khi tương tác."""
    if distance is None:
        distance = random.randint(100, 400)
    try:
        driver.execute_script(f"""
            window.scrollBy({{top: {distance}, behavior: 'smooth'}});
        """)
        time.sleep(_rand(0.4, 0.9))
        # Scroll ngược lại một chút
        driver.execute_script(f"""
            window.scrollBy({{top: -{distance // 3}, behavior: 'smooth'}});
        """)
        time.sleep(_rand(0.2, 0.5))
    except Exception:
        pass


def click_18(driver):
    """Bấm nút xác nhận tuổi — dùng human click."""
    for xp in [
        "//button[contains(text(), 'Tôi từ 18')]",
        "//button[contains(text(), 'I am 18')]",
        "//button[contains(., '18')]",
    ]:
        try:
            btn = WebDriverWait(driver, 2).until(EC.element_to_be_clickable((By.XPATH, xp)))
            time.sleep(random.uniform(0.4, 0.8))
            _human_click(driver, btn)
            time.sleep(_rand(0.8, 1.5))
            return True
        except Exception:
            continue
    return False


def type_slowly(element, text, delay=0.08):
    """Legacy — dùng _human_type thay thế khi có driver context."""
    try:
        element.click()
        element.clear()
    except Exception:
        pass
    try:
        d = element.parent
        d.execute_script("arguments[0].value='';arguments[0].dispatchEvent(new Event('input',{bubbles:true}));", element)
    except Exception:
        pass
    time.sleep(0.05)
    for c in text:
        element.send_keys(c)
        time.sleep(delay + random.uniform(-0.02, 0.03))
    try:
        element.parent.execute_script(
            "arguments[0].dispatchEvent(new Event('input',{bubbles:true}));"
            "arguments[0].dispatchEvent(new Event('change',{bubbles:true}));", element)
    except Exception:
        pass

# ======================== OTP FAST POLL ⚡ ========================

def extract_otp(text: str) -> Optional[str]:
    """Trích xuất OTP 6 chữ số từ nội dung email."""
    if not text:
        return None
    t = text.lower()
    for pattern in [
        r'(?:otp|code|mã|pin|verification|confirm|xác\s*nhận|xác\s*minh)\s*[:\s]+(\d{6})\b',
        r'\b(\d{6})\b\s*(?:is your|là mã|verification|xác nhận)',
    ]:
        m = re.search(pattern, t, re.IGNORECASE)
        if m:
            return m.group(1)
    for m in re.finditer(r'(?<!\d)(\d{6})(?!\d)', t):
        candidate = m.group(1)
        start = max(0, m.start() - 30)
        ctx = t[start: m.end() + 10]
        if any(k in ctx for k in ("otp", "code", "mã", "pin", "verify", "xác")):
            return candidate
    m = re.search(r'(?<!\d)(\d{6})(?!\d)', t)
    if m:
        return m.group(1)
    return None


def _check_mailtm_otp(auth: dict) -> Optional[str]:
    """Kiểm tra 1 lần inbox Mail.tm, trả về OTP nếu tìm thấy."""
    token = auth.get("token")
    api_base = auth.get("api_base", MAILTM_API)
    if not token:
        return None
    try:
        r = requests.get(
            api_base.rstrip("/") + "/messages",
            headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
            timeout=8
        )
        if r.status_code == 401:
            t = requests.post(
                api_base.rstrip("/") + "/token",
                json={"address": auth["email"], "password": auth["password"]},
                headers={"Content-Type": "application/json"}, timeout=8
            )
            if t.status_code == 200:
                new_tok = t.json().get("token") or t.json().get("accessToken")
                if new_tok:
                    auth["token"] = new_tok
            return None
        if r.status_code != 200:
            return None
        data = r.json()
        msgs = data if isinstance(data, list) else (data.get("hydra:member") or data.get("member") or [])
        for msg in msgs[:10]:
            if not isinstance(msg, dict):
                continue
            mid = msg.get("id")
            if not mid:
                continue
            d = requests.get(
                api_base.rstrip("/") + f"/messages/{mid}",
                headers={"Authorization": f"Bearer {auth.get('token', token)}", "Accept": "application/json"},
                timeout=8
            )
            if d.status_code != 200:
                continue
            detail = d.json()
            parts = []
            for field in ("html", "text"):
                v = detail.get(field)
                if isinstance(v, list):
                    parts.extend(str(x) for x in v if x)
                elif v:
                    parts.append(str(v))
            for field in ("intro", "subject"):
                if detail.get(field):
                    parts.append(str(detail[field]))
            otp = extract_otp(" ".join(parts))
            if otp:
                return otp
    except Exception as e:
        logger.debug("[MAILTM OTP] error: %s", e)
    return None


def _check_guerrilla_otp(auth: dict) -> Optional[str]:
    """Kiểm tra 1 lần inbox Guerrilla, trả về OTP nếu tìm thấy."""
    sid = auth.get("sid_token")
    if not sid:
        return None
    try:
        seq = auth.get("_seq", 0)
        r = requests.get(GUERRILLA_API,
                         params={"f": "check_email", "sid_token": sid, "seq": seq}, timeout=8)
        if r.status_code != 200:
            return None
        data = r.json()
        if data.get("seq") is not None:
            auth["_seq"] = int(data["seq"])
        for item in (data.get("list") or []):
            if not isinstance(item, dict):
                continue
            mid = item.get("mail_id")
            if not mid:
                continue
            d = requests.get(GUERRILLA_API,
                             params={"f": "fetch_email", "email_id": mid, "sid_token": sid}, timeout=8)
            if d.status_code != 200:
                continue
            m = d.json()
            body = " ".join(filter(None, [m.get("mail_subject",""), m.get("mail_body",""), m.get("mail_excerpt","")]))
            otp = extract_otp(body)
            if otp:
                return otp
    except Exception as e:
        logger.debug("[GUERRILLA OTP] error: %s", e)
    return None


def poll_otp_fast(auth: dict, timeout: int = 60) -> Optional[str]:
    """⚡ Rapid-fire OTP poll — 2 threads lệch pha, poll mỗi 0.5s."""
    provider = auth.get("provider", "mailtm")
    checker = _check_guerrilla_otp if provider == "guerrilla" else _check_mailtm_otp
    found = threading.Event()
    result: List[str] = []
    lock = threading.Lock()
    start = time.time()

    def worker(delay: float = 0.0):
        time.sleep(delay)
        while not found.is_set() and (time.time() - start) < timeout:
            otp = checker(auth)
            if otp:
                with lock:
                    if not result:
                        result.append(otp)
                found.set()
                logger.info("[OTP] ✅ Got OTP=%s in %.1fs", otp, time.time() - start)
                return
            time.sleep(EMAIL_POLL_INTERVAL)

    t1 = threading.Thread(target=worker, args=(0,), daemon=True)
    t2 = threading.Thread(target=worker, args=(EMAIL_POLL_INTERVAL / 2,), daemon=True)
    t1.start(); t2.start()
    poll = 0
    while not found.is_set():
        if time.time() - start >= timeout:
            logger.warning("[OTP] Timeout after %.0fs", time.time() - start)
            break
        poll += 1
        if poll % 20 == 0:
            logger.info("[OTP] Still waiting... %.0fs", time.time() - start)
        time.sleep(1)
    t1.join(timeout=2); t2.join(timeout=2)
    return result[0] if result else None


def enter_otp_on_site(driver, otp: str) -> bool:
    """Click vào OTP input, nhập OTP, bấm nút Tiếp tục (giống code gốc)."""
    from selenium.webdriver.common.keys import Keys
    inp = None
    # Tìm OTP input — nhiều selector fallback
    for by, sel in [
        (By.CSS_SELECTOR, 'input[name="code"]'),
        (By.CSS_SELECTOR, 'input[autocomplete="one-time-code"]'),
        (By.XPATH, '//input[@name="code"]'),
        (By.XPATH, '//input[@autocomplete="one-time-code"]'),
    ]:
        try:
            inp = WebDriverWait(driver, 6).until(EC.presence_of_element_located((by, sel)))
            if inp and inp.is_displayed():
                break
        except Exception:
            inp = None

    if not inp:
        logger.error("[OTP] Input not found")
        return False

    try:
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", inp)
        inp.click(); time.sleep(random.uniform(0.2, 0.4))
        inp.send_keys(Keys.CONTROL + "a"); inp.send_keys(Keys.DELETE); time.sleep(0.1)
        for digit in otp:
            inp.send_keys(digit)
            time.sleep(random.uniform(0.1, 0.22))
        driver.execute_script(
            "arguments[0].dispatchEvent(new Event('input',{bubbles:true}));"
            "arguments[0].dispatchEvent(new Event('change',{bubbles:true}));", inp)
        logger.info("[OTP] Entered OTP=%s", otp)
        time.sleep(random.uniform(0.5, 1.0))
    except Exception as e:
        logger.error("[OTP] Input error: %s", e)
        return False

    # Tìm nút "Tiếp tục" — multi-XPath fallback (dùng contains(.,...) — lấy ALL text)
    for xp in [
        "//button[contains(@class,'bg-gradient-to-r') and contains(@class,'from-primary') and contains(.,'Tiếp tục')]",
        "//button[contains(@class,'bg-gradient-to-b') and contains(@class,'from-') and contains(.,'Tiếp tục')]",
        "//button[contains(@class,'from-primary') and contains(.,'Tiếp tục')]",
        "//button[normalize-space(text())='Tiếp tục']",
        "//button[contains(.,'Tiếp tục')]",
        "//button[contains(.,'Continue')]",
        "//button[contains(.,'Xác nhận')]",
        "//button[@type='submit']",
    ]:
        try:
            btn = WebDriverWait(driver, 3).until(EC.element_to_be_clickable((By.XPATH, xp)))
            if btn.is_displayed() and btn.is_enabled():
                driver.execute_script("arguments[0].scrollIntoView({block:'center'});", btn)
                time.sleep(0.1)
                try: btn.click()
                except Exception: driver.execute_script("arguments[0].click();", btn)
                logger.info("[OTP] Submit clicked via: %s", xp[:60])
                return True
        except Exception:
            continue

    # Fallback: Enter key
    try:
        inp.send_keys(Keys.RETURN)
        logger.info("[OTP] Submit via Enter key")
        return True
    except Exception:
        return False

# ======================== SIGNUP HELPERS ========================

def _fill_signup_form(driver, email: str, pwd: str,
                      slow: bool = False) -> bool:
    """
    Điền form như người thực: scroll nhẹ → hover → click → gõ từng ký tự.
    slow=True: delay lớn hơn khi submit thất bại nhiều lần.
    """
    _human_scroll(driver, random.randint(60, 150))

    deadline = time.time() + (30 if slow else 22)
    while time.time() < deadline:
        try:
            ei = driver.find_elements(By.CSS_SELECTOR, 'input[type="email"],input[name="email"]')
            pi = driver.find_elements(By.CSS_SELECTOR, 'input[type="password"],input[name="password"]')
            if not (ei and pi and ei[0].is_displayed() and pi[0].is_displayed()):
                time.sleep(0.4); continue

            email_inp, pass_inp = ei[0], pi[0]

            # Hover qua form tự nhiên trước khi điền
            try:
                from selenium.webdriver.common.action_chains import ActionChains
                ActionChains(driver).move_to_element(email_inp).pause(_rand(0.2, 0.5)).perform()
            except Exception:
                pass

            _human_type(driver, email_inp, email, clear=True)
            time.sleep(_rand(0.3, 0.6))
            _human_type(driver, pass_inp, pwd, clear=True)

            got_email = email_inp.get_attribute("value") or ""
            got_pass  = pass_inp.get_attribute("value") or ""
            if got_email == email and len(got_pass) == len(pwd):
                logger.info("[REGISTER] Form filled (human): email=%s", email)
                return True
            logger.warning("[REGISTER] Verify failed, retrying...")
        except Exception as e:
            logger.debug("[REGISTER] fill error: %s", e)
        time.sleep(_rand(0.5, 1.0) if slow else _rand(0.3, 0.5))
    return False


def _click_submit(driver, email: str = "", pwd: str = "",
                  slow: bool = False) -> bool:
    """
    Click nút submit tự nhiên — dùng _human_click thay vì JS click.
    Re-assert field values trước khi click.
    """
    # Re-check fields
    if email or pwd:
        try:
            ei = driver.find_elements(By.CSS_SELECTOR, 'input[type="email"],input[name="email"]')
            pi = driver.find_elements(By.CSS_SELECTOR, 'input[type="password"],input[name="password"]')
            if ei and ei[0].is_displayed() and (ei[0].get_attribute("value") or "") != email:
                _human_type(driver, ei[0], email, clear=True)
                time.sleep(_rand(0.1, 0.3))
            if pi and pi[0].is_displayed() and len(pi[0].get_attribute("value") or "") != len(pwd):
                _human_type(driver, pi[0], pwd, clear=True)
                time.sleep(_rand(0.1, 0.3))
        except Exception:
            pass

    for xp in [
        "//button[@type='submit']",
        "//button[contains(text(),'Tạo tài khoản')]",
        "//button[contains(text(),'Đăng ký')]",
        "//button[contains(text(),'Continue')]",
        "//button[contains(text(),'Tiếp tục')]",
        "//button[contains(@class,'bg-gradient-to-r')]",
        "//button[contains(@class,'from-primary')]",
    ]:
        try:
            for btn in driver.find_elements(By.XPATH, xp):
                if btn.is_displayed() and btn.is_enabled() and \
                   btn.get_attribute("disabled") not in ("true", "disabled"):
                    time.sleep(_rand(0.3, 0.8) if slow else _rand(0.1, 0.4))
                    _human_click(driver, btn)
                    logger.info("[REGISTER] Submit clicked (%s) via: %s",
                                "slow" if slow else "human", xp[:50])
                    return True
        except Exception:
            continue
    return False


def _handle_cloudflare(driver):
    """
    Xử lý Cloudflare Turnstile nâng cao:
    - Chờ iframe load đầy đủ (Turnstile cần thời gian khởi tạo)
    - Di chuyển chuột đến widget trước khi click (mouse entropy)
    - Click tự nhiên qua _human_click thay vì JS click
    - Retry nếu widget bị reset (isFailed/isExpired)
    - Timeout 10s/lần, tối đa 3 lần thử
    """
    for retry in range(3):
        try:
            # Tìm tất cả Cloudflare iframes (Turnstile dùng challenges.cloudflare.com)
            iframes = driver.find_elements(By.XPATH,
                "//iframe[contains(@src,'challenges.cloudflare.com') or "
                "contains(@src,'cloudflare.com/cdn-cgi/challenge')]"
            )
            if not iframes:
                return  # Không có Turnstile — OK

            for ifr in iframes:
                # Scroll iframe vào viewport trước
                try:
                    driver.execute_script(
                        "arguments[0].scrollIntoView({block:'center', behavior:'smooth'});", ifr
                    )
                    time.sleep(_rand(0.5, 1.0))
                except Exception:
                    pass

                # Di chuyển chuột đến vùng iframe — tạo mouse activity
                try:
                    from selenium.webdriver.common.action_chains import ActionChains
                    ActionChains(driver).move_to_element(ifr).pause(_rand(0.3, 0.7)).perform()
                    time.sleep(_rand(0.2, 0.5))
                except Exception:
                    pass

                driver.switch_to.frame(ifr)

                # Chờ widget load — Turnstile cần 1-3s để khởi tạo
                time.sleep(_rand(1.5, 3.0))

                # Tìm checkbox/label của Turnstile
                clicked = False
                selectors = [
                    "input[type='checkbox']",
                    "div[role='checkbox']",
                    "label",                      # Turnstile dùng label bao ngoài
                    "span.cb-i",
                    "div.cb-i",
                    "[id*='turnstile']",
                    "[class*='turnstile']",
                    "body",                        # last resort — click vào body của iframe
                ]
                for sel in selectors:
                    try:
                        els = driver.find_elements(By.CSS_SELECTOR, sel)
                        for el in els:
                            if el.is_displayed():
                                # Di chuyển chuột đến element trước
                                try:
                                    ActionChains(driver).move_to_element(el)\
                                        .pause(_rand(0.2, 0.5)).perform()
                                except Exception:
                                    pass
                                time.sleep(_rand(0.1, 0.3))

                                # Click tự nhiên
                                try:
                                    el.click()
                                except Exception:
                                    try:
                                        ActionChains(driver).click(el).perform()
                                    except Exception:
                                        driver.execute_script("arguments[0].click();", el)

                                logger.info("[CF] Turnstile clicked via: %s", sel)
                                clicked = True
                                time.sleep(_rand(0.5, 1.2))
                                break
                        if clicked:
                            break
                    except Exception:
                        continue

                driver.switch_to.default_content()

                # Chờ Turnstile xử lý (watchcat interval ~900ms, retry timeout ~8000ms)
                time.sleep(_rand(2.0, 4.0))

                # Kiểm tra nếu đã vượt qua (token xuất hiện hoặc redirect)
                try:
                    token = driver.execute_script(
                        "return document.querySelector('[name=\"cf-turnstile-response\"]')"
                        "?.value || '';"
                    )
                    if token and len(token) > 10:
                        logger.info("[CF] ✅ Turnstile token obtained")
                        return
                except Exception:
                    pass

        except Exception as e:
            logger.debug("[CF] Turnstile attempt %d error: %s", retry + 1, e)
            try:
                driver.switch_to.default_content()
            except Exception:
                pass
            time.sleep(_rand(1.0, 2.0))




def reopen_clean_tab(driver, target_url="https://ai-undress.ai/vi"):
    """
    Đóng hẳn tab cũ và mở tab mới hoàn toàn thay vì refresh trang.
    Giúp reset hoàn toàn state, tránh lưu cache hỏng hoặc bị Cloudflare chặn reload.
    """
    try:
        try:
            curr_handle = driver.current_window_handle
        except Exception:
            curr_handle = None

        # Mở tab mới sạch
        driver.execute_script(f"window.open('{target_url}', '_blank');")
        time.sleep(0.5)

        handles = driver.window_handles
        new_handles = [h for h in handles if h != curr_handle]
        if new_handles:
            new_tab = new_handles[-1]
            if curr_handle and curr_handle in handles:
                try:
                    driver.switch_to.window(curr_handle)
                    driver.close()
                except Exception:
                    pass
            driver.switch_to.window(new_tab)
        else:
            driver.get(target_url)

        time.sleep(random.uniform(1.2, 2.0))
        logger.info("[TAB] 🔄 Đã đóng hẳn tab cũ và mở tab mới thành công: %s", target_url)
        return True
    except Exception as e:
        logger.warning("[TAB] reopen_clean_tab failed: %s, fallback to get()", e)
        try:
            driver.get(target_url)
        except Exception:
            pass
        return False

def register(driver, mail_data: dict) -> bool:
    """
    Flow mới (UI 2026) — GIỮ NGUYÊN LOGIC GỐC:
      1. Mở ai-undress.ai/vi → Bắt đầu → Tiếp tục bằng email
      2. Điền form (dùng _fill_signup_form + _click_submit giống code gốc)
      3. OTP input xuất hiện → poll_otp_fast → enter_otp_on_site
      4. Check redirect khỏi auth URL → done
      5. Claim daily credit (bonus)

    Behavior:
      - Nút "Tạo tài khoản" fail 3 lần → refresh tab (tối đa 5 lần refresh → quit Chrome)
      - Sau khi nhập OTP + submit: TAB LOCKED — không reload/close, retry cùng tab
    """
    email     = mail_data["email"]
    mail_auth = mail_data.get("auth")
    pwd       = mail_data.get("password", email)

    attempt = 0
    create_refresh_count = 0  # số lần refresh do "Tạo tài khoản" fail (max 5 → quit)

    while attempt < 15:
        attempt += 1
        logger.info("[REGISTER] Attempt #%d — %s (refresh: %d/5)",
                    attempt, email, create_refresh_count)
        try: driver.delete_all_cookies()
        except Exception: pass

        # ── Bước 1: Mở trang chủ ──────────────────────────────────────
        nav_ok = False
        for nav_try in range(3):
            try:
                driver.get("https://ai-undress.ai/vi")
                WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.TAG_NAME, "body"))
                )
                cur = driver.current_url or ""
                if "data:" in cur or cur.strip() in ("", "about:blank"):
                    logger.warning("[REGISTER] Bad URL after get(): %s — retry %d/3", cur, nav_try + 1)
                    time.sleep(1.5)
                    continue
                nav_ok = True
                break
            except Exception as e:
                logger.warning("[REGISTER] Navigation attempt %d failed: %s", nav_try + 1, e)
                time.sleep(1.5)

        if not nav_ok:
            logger.error("[REGISTER] Failed to open ai-undress.ai after 3 tries")
            continue

        # Để trang tải ổn định và nhìn trang tự nhiên như người dùng thật (0.9 - 1.5s)
        time.sleep(random.uniform(0.9, 1.5))
        click_18(driver)
        time.sleep(random.uniform(0.4, 0.8))

        # ── Bước 1.1: Bấm "Bắt đầu" (tự nhiên như người thật) ─────────
        clicked_start = False
        _start_xpaths = [
            "//button[contains(.,'Bắt đầu')]",
            "//button[contains(.,'Start')]",
            "//button[contains(.,'Get Started')]",
            "//button[contains(@class,'from-primary') and contains(@class,'rounded-full')]",
        ]
        _start_deadline = time.time() + 10
        while time.time() < _start_deadline and not clicked_start:
            for xp in _start_xpaths:
                try:
                    btns = driver.find_elements(By.XPATH, xp)
                    for btn in btns:
                        if btn.is_displayed() and btn.is_enabled():
                            time.sleep(random.uniform(0.5, 0.9))  # Người thật nhìn thấy nút rồi bấm
                            _human_click(driver, btn)
                            logger.info("[REGISTER] ✅ Clicked 'Bắt đầu' via: %s", xp[:60])
                            clicked_start = True
                            time.sleep(random.uniform(0.7, 1.2))
                            break
                except Exception:
                    continue
                if clicked_start:
                    break
            if not clicked_start:
                time.sleep(0.3)
        if not clicked_start:
            logger.warning("[REGISTER] 'Bắt đầu' not found")
            continue

        # ── Bước 2: Bấm "Tiếp tục bằng email" (chờ modal mở tự nhiên) ──
        clicked_email = False
        _email_xpaths = [
            "//button[.//svg[contains(@class,'lucide-mail')] and contains(.,'Tiếp tục bằng email')]",
            "//button[.//svg[contains(@class,'lucide-mail')] and contains(.,'email')]",
            "//button[contains(.,'Tiếp tục bằng email')]",
            "//button[contains(.,'Continue with email')]",
            "//button[contains(.,'bằng email')]",
            "//button[.//svg[contains(@class,'lucide-mail')]]",
        ]
        _email_deadline = time.time() + 10
        while time.time() < _email_deadline and not clicked_email:
            for xp in _email_xpaths:
                try:
                    btns = driver.find_elements(By.XPATH, xp)
                    for btn in btns:
                        if btn.is_displayed() and btn.is_enabled():
                            time.sleep(random.uniform(0.6, 1.0))  # Người thật định vị nút email trong popup
                            _human_click(driver, btn)
                            logger.info("[REGISTER] ✅ Clicked 'Tiếp tục bằng email' via: %s", xp[:60])
                            clicked_email = True
                            time.sleep(random.uniform(0.7, 1.2))
                            break
                except Exception:
                    continue
                if clicked_email:
                    break
            if not clicked_email:
                time.sleep(0.3)
        if not clicked_email:
            logger.warning("[REGISTER] Email button not found")
            continue

        # ── Bước 3: Điền email + password (dùng _fill_signup_form giống code gốc) ──
        if not _fill_signup_form(driver, email, pwd):
            logger.warning("[REGISTER] Could not fill form")
            continue

        _handle_cloudflare(driver)

        # ── Kiểm tra nút Tạo tài khoản sáng trong 5s, nếu không → refresh ──
        submit_enabled = False
        check_deadline = time.time() + 5
        while time.time() < check_deadline:
            for xp in ["//button[@type='submit']", "//button[contains(.,'Tạo tài khoản')]", "//button[contains(.,'Create account')]"]:
                try:
                    btns = driver.find_elements(By.XPATH, xp)
                    for btn in btns:
                        if btn.is_displayed() and btn.is_enabled() and btn.get_attribute("disabled") not in ("true", "disabled"):
                            submit_enabled = True
                            break
                except Exception:
                    pass
                if submit_enabled:
                    break
            if submit_enabled:
                break
            time.sleep(0.3)

        if not submit_enabled:
            create_refresh_count += 1
            logger.warning("[REGISTER] ⚠️ Submit button not enabled after 5s → Đóng hẳn tab và bật lại #%d/5", create_refresh_count)
            if create_refresh_count >= 5:
                logger.error("[REGISTER] ❌ 5 lần đóng mở tab thất bại → Closing Chrome")
                try: driver.quit()
                except Exception: pass
                return False
            reopen_clean_tab(driver, "https://ai-undress.ai/vi")
            continue

        # ── Bước 4: Bấm "Tạo tài khoản" — 3 lần thử, fail → refresh ──
        create_clicked = False
        deadline_btn = time.time() + 20
        while time.time() < deadline_btn:
            for xp in [
                "//button[@type='submit' and contains(.,'Tạo tài khoản')]",
                "//button[contains(.,'Tạo tài khoản')]",
                "//button[@type='submit' and contains(.,'Create account')]",
                "//button[contains(.,'Create account')]",
                "//button[@type='submit' and contains(.,'Đăng ký')]",
                "//button[contains(@class,'from-') and @type='submit']",
                "//button[@type='submit']",
            ]:
                try:
                    for btn in driver.find_elements(By.XPATH, xp):
                        if btn.is_displayed() and btn.is_enabled() and \
                           btn.get_attribute("disabled") not in ("true", "disabled"):
                            _human_click(driver, btn)
                            logger.info("[REGISTER] ✅ Clicked 'Tạo tài khoản' via: %s", xp[:60])
                            create_clicked = True
                            time.sleep(2)
                            break
                except Exception:
                    continue
                if create_clicked:
                    break
            if create_clicked:
                break
            _handle_cloudflare(driver)
            time.sleep(1)

        # ── Nếu không bấm được → ĐÓNG HẲN TAB VÀ MỞ LẠI ────────────────
        if not create_clicked:
            create_refresh_count += 1
            logger.warning("[REGISTER] ⚠️ Create button failed → Đóng hẳn tab và bật lại #%d/5",
                           create_refresh_count)
            if create_refresh_count >= 5:
                logger.error("[REGISTER] ❌ 5 lần đóng mở tab thất bại → Closing Chrome")
                try: driver.quit()
                except Exception: pass
                return False
            reopen_clean_tab(driver, "https://ai-undress.ai/vi")
            continue

        # ── Check "Email đã được sử dụng" — SAU khi submit form ──────
        # Dùng contains(text(),...) — chỉ direct text node, tránh false positive
        # (contains(.,...) match element cha như <body> nếu có error template ẩn)
        time.sleep(1.5)
        try:
            taken = driver.find_elements(By.XPATH,
                "//*[contains(text(),'Email này đã được sử dụng') or "
                "contains(text(),'Email has already been taken') or "
                "contains(text(),'already in use') or "
                "contains(text(),'đã được sử dụng')]")
            if taken and any(e.is_displayed() for e in taken):
                logger.warning("[REGISTER] Email taken (after submit), rotating...")
                email, mail_auth, _ = create_temp_mail()
                pwd = email
                mail_data.update({"email": email, "auth": mail_auth, "password": pwd})
                reopen_clean_tab(driver, "https://ai-undress.ai/vi")
                continue
        except Exception:
            pass

        # ── Bước 5: Chờ OTP input xuất hiện ──────────────────────────
        # UI mới: OTP input hiện trên cùng trang (URL không đổi sang /auth/signup)
        # → KHÔNG check redirect = success. Chỉ chờ OTP input.
        otp_appeared = False
        check_end = time.time() + 15
        while time.time() < check_end:
            inps = driver.find_elements(By.CSS_SELECTOR,
                'input[name="code"], input[autocomplete="one-time-code"]')
            if inps and any(i.is_displayed() for i in inps):
                otp_appeared = True
                logger.info("[REGISTER] ✅ OTP input appeared")
                break
            time.sleep(0.5)

        if not otp_appeared:
            logger.warning("[REGISTER] OTP input did not appear (timeout 15s)")
            continue

        # ── Bước 6: Poll OTP ─────────────────────────────────────────
        logger.info("[REGISTER] Polling OTP...")
        otp = poll_otp_fast(mail_auth, timeout=60)
        if not otp:
            logger.error("[REGISTER] OTP not received")
            time.sleep(3)
            continue

        logger.info("[REGISTER] ✅ OTP=%s — TAB LOCKED", otp)

        # ── Bước 7+8: Nhập OTP — TAB LOCKED (không reload/close) ────
        registration_success = False
        current_otp = otp
        for otp_try in range(4):
            logger.info("[REGISTER] OTP attempt %d/4", otp_try + 1)

            if not enter_otp_on_site(driver, current_otp):
                logger.warning("[REGISTER] enter_otp_on_site failed (%d/4)", otp_try + 1)
                time.sleep(1.5)
                continue  # retry cùng tab

            # Chờ xử lý + detect success (UI mới: URL không đổi, phải check state khác)
            # Success = OTP input BIẾN MẤT (form chuyển trạng thái) VÀ không có error
            time.sleep(3)
            try:
                errs = driver.find_elements(By.XPATH,
                    "//*[contains(text(),'mã không đúng') or contains(text(),'invalid code') or "
                    "contains(text(),'incorrect') or contains(text(),'expired') or "
                    "contains(text(),'không đúng') or contains(text(),'sai mã')]")
                has_error = any(e.is_displayed() for e in errs if e)
            except Exception:
                has_error = False

            if has_error:
                logger.warning("[REGISTER] ❌ OTP error (%d/4) → polling new OTP", otp_try + 1)
                new_otp = poll_otp_fast(mail_auth, timeout=40)
                if new_otp and new_otp != current_otp:
                    logger.info("[REGISTER] Got new OTP=%s", new_otp)
                    current_otp = new_otp
                else:
                    time.sleep(1.5)
                continue

            # Không có error → check OTP input có còn visible không
            try:
                otp_inputs = driver.find_elements(By.CSS_SELECTOR,
                    'input[name="code"], input[autocomplete="one-time-code"]')
                otp_still_visible = any(i.is_displayed() for i in otp_inputs)
            except Exception:
                otp_still_visible = False

            if not otp_still_visible:
                logger.info("[REGISTER] ✅ OTP input gone → Registration SUCCESS!")
                registration_success = True
                break

            # OTP input vẫn còn → có thể vẫn đang xử lý, chờ thêm 1 lần
            time.sleep(2)
            try:
                otp_inputs2 = driver.find_elements(By.CSS_SELECTOR,
                    'input[name="code"], input[autocomplete="one-time-code"]')
                otp_still_visible2 = any(i.is_displayed() for i in otp_inputs2)
            except Exception:
                otp_still_visible2 = False

            if not otp_still_visible2:
                logger.info("[REGISTER] ✅ OTP input gone (2nd check) → SUCCESS!")
                registration_success = True
                break

            # Vẫn còn OTP input + không có error → thử lại (có thể submit chưa nhận)
            logger.warning("[REGISTER] OTP input still visible, retrying (%d/4)", otp_try + 1)

        if not registration_success:
            logger.error("[REGISTER] OTP flow failed after 4 tries (TAB KEPT ALIVE)")
            return False

        logger.info("[REGISTER] ✅ Registration SUCCESS!")
        _claim_daily_credit(driver)
        return True

    logger.error("[REGISTER] All attempts failed")
    return False


def _claim_daily_credit(driver):
    """Claim daily credit sau khi đăng ký thành công."""
    try:
        # Nút "Tín dụng hằng ngày"
        daily_btn = None
        deadline = time.time() + 5
        while time.time() < deadline:
            for xp in [
                "//button[@aria-label='Tín dụng hằng ngày']",
                "//button[@aria-label='Daily credit']",
                "//button[@aria-label='Daily credits']",
                "//button[.//svg[contains(@class,'lucide-gift')] and contains(@class,'rounded-full')]",
                "//button[.//svg[contains(@class,'lucide-gift')]]",
            ]:
                btns = driver.find_elements(By.XPATH, xp)
                for b in btns:
                    if b.is_displayed() and b.is_enabled():
                        daily_btn = b
                        break
                if daily_btn:
                    break
            if daily_btn:
                break
            time.sleep(0.3)

        if daily_btn:
            _human_click(driver, daily_btn)
            logger.info("[CREDIT] ✅ Clicked daily credit button")
            time.sleep(1.5)

        # Popup "Nhận ngay!"
        for xp in [
            "//button[contains(.,'Nhận ngay')]",
            "//button[contains(.,'Claim')]",
            "//button[contains(.,'Nhận')]",
            "//button[.//svg[contains(@class,'lucide-gift')] and contains(.,'Nhận')]",
        ]:
            try:
                btns = driver.find_elements(By.XPATH, xp)
                for b in btns:
                    if b.is_displayed() and b.is_enabled():
                        _human_click(driver, b)
                        logger.info("[CREDIT] ✅ Claimed popup credit")
                        time.sleep(0.8)
                        return
            except Exception:
                continue
    except Exception as e:
        logger.warning("[CREDIT] Claim failed: %s", e)




def login(driver, email, pwd):
    try:
        btns = driver.find_elements(By.XPATH, "//button[contains(text(),'Đăng nhập')]")
        if btns and btns[0].is_displayed():
            driver.execute_script("arguments[0].click();", btns[0])
            time.sleep(2)
        else:
            return True
        ei = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.NAME, "email")))
        pi = driver.find_element(By.NAME, "password")
        driver.execute_script("arguments[0].value=arguments[1];", ei, email)
        driver.execute_script("arguments[0].value=arguments[1];", pi, pwd)
        time.sleep(1)
        driver.execute_script("arguments[0].click();", driver.find_element(By.XPATH, "//button[@type='submit']"))
        time.sleep(5)
        return True
    except Exception as e:
        logger.error("Login error: %s", e)
        return True

def find_upload(driver):
    """Find file upload input on editor page"""
    try:
        # Wait for the editor page to load
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'input[type="file"]'))
        )
        upload = driver.find_element(By.CSS_SELECTOR, 'input[type="file"]')
        logger.info("[UPLOAD] ✅ Found upload input")
        return upload
    except Exception as e:
        logger.error("[UPLOAD] Failed to find upload input: %s", e)
        return None


def click_upload_confirm(driver, timeout=10) -> bool:
    """
    Bấm nút 'Confirm' sau khi upload ảnh.
    Nút: <button class="... bg-gradient-to-r from-primary to-ring ...">Confirm</button>
    """
    # Chờ nút Confirm xuất hiện + clickable
    deadline = time.time() + timeout
    while time.time() < deadline:
        for xp in [
            "//button[contains(@class,'from-primary') and contains(@class,'to-ring') and contains(text(),'Confirm')]",
            "//button[contains(@class,'bg-gradient-to-r') and contains(.,'Confirm')]",
            "//button[contains(text(),'Confirm')]",
            "//button[contains(.,'Confirm') and @type='button']",
            "//button[contains(.,'Confirm')]",
            "//button[contains(.,'Xác nhận') and contains(@class,'from-primary')]",
            "//button[contains(.,'Xác nhận')]",
        ]:
            try:
                btns = driver.find_elements(By.XPATH, xp)
                for b in btns:
                    if b.is_displayed() and b.is_enabled() and \
                       b.get_attribute("disabled") not in ("true", "disabled"):
                        driver.execute_script(
                            "arguments[0].scrollIntoView({block:'center'});", b)
                        time.sleep(0.3)
                        _human_click(driver, b)
                        logger.info("[UPLOAD] ✅ Clicked 'Confirm' via: %s", xp[:60])
                        time.sleep(1.5)  # chờ xử lý upload
                        return True
            except Exception:
                continue
        time.sleep(0.5)
    logger.warning("[UPLOAD] 'Confirm' button not found (timeout %ds)", timeout)
    return False

def click_create(driver):
    """Click nút 'Tạo' (Create) — multi-XPath fallback giống code gốc."""
    for xp in [
        "//button[contains(@class,'rounded-full') and contains(.,'Tạo')]",
        "//button[.//svg[contains(@class,'lucide-sparkles')] and contains(.,'Tạo')]",
        "//button[.//svg[contains(@class,'lucide-sparkles')]]",
        "//button[contains(.,'Tạo')]",
        "//button[contains(.,'Create')]",
        "//button[contains(.,'Generate')]",
        "//button[contains(text(),'Tạo')]",
    ]:
        try:
            btn = WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, xp)))
            if btn.is_displayed() and btn.is_enabled():
                driver.execute_script("arguments[0].scrollIntoView({block:'center'});", btn)
                time.sleep(0.3)
                _human_click(driver, btn)
                logger.info("[CREATE] ✅ Clicked 'Tạo' via: %s", xp[:60])
                time.sleep(2)
                return True
        except Exception:
            continue
    logger.error("[CREATE] Failed to click create button")
    return False
def click_close_popup(driver, timeout=10):
    """
    Chờ popup hiện lên và bấm nút close (X).
    Nút close có dạng:
    <button type="button" class="absolute right-4 top-4 rounded-full bg-white/5 p-1.5 text-white/60 hover:bg-white/10 hover:text-white transition-colors" aria-label="Close">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x h-4 w-4">
            <path d="M18 6 6 18"></path>
            <path d="m6 6 12 12"></path>
        </svg>
    </button>
    """
    try:
        # Cách 1: Tìm theo aria-label="Close"
        close_btn = WebDriverWait(driver, timeout).until(
            EC.element_to_be_clickable((By.XPATH, "//button[@aria-label='Close']"))
        )
        driver.execute_script("arguments[0].click();", close_btn)
        logger.info("✅ Popup closed via aria-label='Close'")
        time.sleep(1)
        return True
    except Exception:
        pass

    # Cách 2: Tìm theo class chứa "absolute right-4 top-4"
    try:
        close_btn = WebDriverWait(driver, timeout).until(
            EC.element_to_be_clickable((By.XPATH, "//button[contains(@class,'absolute right-4 top-4')]"))
        )
        driver.execute_script("arguments[0].click();", close_btn)
        logger.info("✅ Popup closed via class selector")
        time.sleep(1)
        return True
    except Exception:
        pass

    # Cách 3: Tìm SVG icon X (lucide-x) rồi click parent button
    try:
        close_svg = WebDriverWait(driver, timeout).until(
            EC.presence_of_element_located((By.XPATH, "//*[contains(@class,'lucide-x')]"))
        )
        parent_btn = close_svg.find_element(By.XPATH, "ancestor::button")
        driver.execute_script("arguments[0].click();", parent_btn)
        logger.info("✅ Popup closed via SVG icon")
        time.sleep(1)
        return True
    except Exception:
        pass

    # Cách 4: Tìm bất kỳ nút nào có text/icon close
    try:
        for xpath in [
            "//button[contains(.,'Close')]",
            "//button[contains(@class,'close')]",
            "//div[contains(@class,'close')]",
            "//span[contains(@class,'close')]"
        ]:
            btns = driver.find_elements(By.XPATH, xpath)
            for btn in btns:
                if btn.is_displayed():
                    driver.execute_script("arguments[0].click();", btn)
                    logger.info("✅ Popup closed via fallback xpath")
                    time.sleep(1)
                    return True
    except Exception:
        pass

    logger.info("ℹ️ No popup to close (or already closed)")
    return False


def select_custom(driver):
    """Navigate to editor page and select Custom Prompt — multi-XPath fallback."""
    try:
        current_url = driver.current_url.lower()
        if "editor" not in current_url:
            driver.get("https://ai-undress.ai/vi/editor?type=undress")
            time.sleep(3)
            logger.info("[CUSTOM] Navigated to editor page")

        _human_scroll(driver, random.randint(400, 600))
        time.sleep(1)

        for xp in [
            "//button[contains(.,'Tùy chỉnh')]",
            "//div[contains(.,'Tùy chỉnh')]",
            "//button[contains(.,'Custom')]",
            "//div[contains(.,'Custom')]",
            "//span[contains(.,'Tùy chỉnh')]",
            "//button[contains(.,'custom')]",
        ]:
            try:
                el = WebDriverWait(driver, 8).until(EC.element_to_be_clickable((By.XPATH, xp)))
                if el.is_displayed():
                    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", el)
                    time.sleep(0.5)
                    ActionChains(driver).move_to_element(el).click().perform()
                    logger.info("[CUSTOM] ✅ Clicked via: %s", xp[:60])
                    time.sleep(1.5)
                    return True
            except Exception:
                continue

        logger.error("[CUSTOM] Custom button not found")
        return False
    except Exception as e:
        logger.error("[CUSTOM] Failed: %s", e)
        return False

def enter_prompt(driver, text):
    """Enter custom prompt — thử nhiều ID/selector."""
    for sel_by, sel_val in [
        (By.ID, "effect-custom-prompt"),
        (By.ID, "sex-pose-custom-prompt"),
        (By.CSS_SELECTOR, "textarea[id*='custom-prompt']"),
        (By.CSS_SELECTOR, "textarea[id*='prompt']"),
        (By.CSS_SELECTOR, "textarea"),
    ]:
        try:
            ta = WebDriverWait(driver, 10).until(EC.presence_of_element_located((sel_by, sel_val)))
            if ta.is_displayed():
                ta.click()
                ta.clear()
                ta.send_keys(text)
                logger.info("[PROMPT] ✅ Entered via %s=%s: %s", sel_by, sel_val, text[:50])
                time.sleep(1)
                return True
        except Exception:
            continue
    logger.error("[PROMPT] Failed to find prompt textarea")
    return False

def get_creations_tab(driver):
    if not is_alive(driver):
        return None
    original = driver.current_window_handle
    new_handle = None
    try:
        driver.execute_script(f"window.open('{CREATIONS_URL}', '_blank');")
        time.sleep(2)
        for h in driver.window_handles:
            if h != original:
                new_handle = h
                break
        if not new_handle:
            return None
        driver.switch_to.window(new_handle)
        WebDriverWait(driver, 30).until(EC.presence_of_element_located((By.CSS_SELECTOR, ".masonry-grid")))
        time.sleep(3)
        for sel in [".masonry-grid img", ".masonry-grid-column img", "[class*='masonry'] img", "img[src*='cdn.treekee.com']"]:
            try:
                for img in driver.find_elements(By.CSS_SELECTOR, sel):
                    src = img.get_attribute("src")
                    if src and "results" in src and "cdn.treekee.com" in src:
                        logger.info("Gallery image found: %s", src)
                        return src
            except Exception:
                continue
        matches = re.findall(r'https?://cdn\.treekee\.com/ai-undress/f1_undress_effects/results/[a-zA-Z0-9_./-]+\.(?:png|jpg|jpeg|webp)', driver.page_source or "", re.I)
        if matches:
            return matches[0]
        return None
    except Exception as e:
        logger.error("Gallery error: %s", e)
        return None
    finally:
        try:
            if new_handle and new_handle in driver.window_handles:
                driver.switch_to.window(new_handle)
                driver.close()
            driver.switch_to.window(original)
        except Exception as e:
            logger.error("Tab cleanup: %s", e)

# ======================== IMAGE UTILS ========================

RESULT_RE = re.compile(r"https?://cdn\.treekee\.com/ai-undress/f1_undress_effects/results/[a-zA-Z0-9_./-]+\.(?:png|jpg|jpeg|webp)(?:\?[^\s\"'<>\]]*)?", re.I)

def is_valid(url):
    if not url:
        return False
    u = url.lower()
    return "cdn.treekee.com" in u and "/results/" in u and not any(s in u for s in ("logo", "icon", "favicon", "brand", "avatar"))

def score_url(url):
    u = unquote(url)
    s = len(u)
    if "f1_undress_effects" in u:
        s += 500
    if "/results/" in u:
        s += 300
    if "w=1200" in u or "w=1920" in u:
        s += 100
    if "logo" in u.lower() or "icon" in u.lower():
        s -= 10000
    return s

def normalize_src(raw, base_url):
    if not raw:
        return None
    src = str(raw).strip().split()[0]
    if src.startswith("//"):
        src = "https:" + src
    elif src.startswith("/"):
        src = urljoin(base_url + "/", src.lstrip("/"))
    if "/_next/image" in src and "url=" in src:
        try:
            inner = parse_qs(urlparse(src).query).get("url", [None])[0]
            if inner:
                src = unquote(inner)
        except Exception:
            pass
    return src

def collect_urls(driver):
    if not is_alive(driver):
        return []
    found = set()
    try:
        base = urlparse(driver.current_url)
        base_url = base.scheme + "://" + base.netloc
    except Exception:
        base_url = "https://ai-undress.ai"
    try:
        for img in driver.find_elements(By.TAG_NAME, "img"):
            for attr in ("src", "data-src", "data-original", "srcset"):
                val = img.get_attribute(attr)
                if not val:
                    continue
                if attr == "srcset":
                    for part in val.split(","):
                        u = normalize_src(part.strip().split()[0], base_url)
                        if u and is_valid(u):
                            found.add(u)
                else:
                    u = normalize_src(val, base_url)
                    if u and is_valid(u):
                        found.add(u)
    except Exception:
        pass
    try:
        for m in RESULT_RE.findall(driver.page_source or ""):
            u = m if m.startswith("http") else urljoin(base_url + "/", m)
            if is_valid(u):
                found.add(u)
    except Exception:
        pass
    return list(found)

def get_best_url(driver):
    time.sleep(1)
    try:
        c = collect_urls(driver)
        if c:
            return max(c, key=score_url)
    except Exception:
        pass
    return None

def wait_result(driver, on_progress=None, max_wait=300):
    poll = 0
    start = time.time()
    gallery_checked = False
    last_url = None
    while True:
        if not is_alive(driver):
            raise WebDriverException("Chrome died")
        poll += 1
        elapsed = time.time() - start

        # Check URL không bị redirect về trang auth vô cớ
        try:
            cur_url = driver.current_url or ""
            if last_url and cur_url != last_url:
                logger.info("[WAIT] URL changed: %s → %s", last_url[:60], cur_url[:60])
                # Nếu bị redirect về auth/home, log warning nhưng không tự refresh
                if "auth" in cur_url.lower() or cur_url.rstrip("/") == "https://ai-undress.ai/vi":
                    logger.warning("[WAIT] ⚠️ Unexpected redirect to: %s", cur_url)
            last_url = cur_url
        except Exception:
            pass

        url = get_best_url(driver)
        if url:
            return url
        if elapsed > max_wait and not gallery_checked:
            gallery_checked = True
            logger.info("5min elapsed, checking gallery")
            if on_progress:
                on_progress("gallery_fallback")
            g = get_creations_tab(driver)
            if g:
                logger.info("Found in gallery")
                return g
            logger.info("Gallery empty, continuing")
        if poll % 10 == 0:
            logger.info("Waiting... poll=%d elapsed=%.0fs", poll, elapsed)
        time.sleep(1)  # Poll mỗi 1s thay vì 2s

def download_img(url, path):
    if not is_valid(url):
        return None
    try:
        r = requests.get(url, timeout=30, headers={"User-Agent": "Mozilla/5.0"})
        if r.status_code == 200:
            with open(path, "wb") as f:
                f.write(r.content)
            logger.info("Downloaded to %s", path)
            return path
    except Exception as e:
        logger.error("Download failed: %s", e)
    return None

def save_to_down_folder(src_path):
    """Copy ảnh đã tải vào mục down với tên ngẫu nhiên 6 chữ số, ví dụ 482917.jpg"""
    if not src_path or not os.path.isfile(src_path):
        return None
    try:
        os.makedirs(DOWN_DIR, exist_ok=True)
        ext = os.path.splitext(src_path)[1] or ".jpg"
        if ext.lower() not in (".jpg", ".jpeg", ".png", ".webp"):
            ext = ".jpg"
        for _ in range(80):
            dest = os.path.join(DOWN_DIR, f"{random.randint(0, 999999):06d}{ext}")
            if not os.path.exists(dest):
                shutil.copy2(src_path, dest)
                logger.info("Saved to down: %s", dest)
                return dest
        logger.warning("Could not find unique 6-digit name in %s", DOWN_DIR)
    except Exception as e:
        logger.error("Save to down failed: %s", e)
    return None

def safe_remove(path):
    if path and os.path.isfile(path):
        try:
            os.remove(path)
        except Exception:
            pass

def progress_bar(pct):
    filled = max(0, min(10, int(pct / 10)))
    return '█' * filled + '░' * (10 - filled) + f' {pct}%'

# ======================== MULTI-CHROME SUPPORT ========================

_active_chrome_processes = []  # Track all Chrome instances
_chrome_lock = threading.Lock()

def spawn_parallel_chrome_if_needed():
    """
    Khi MAX_CHROME_TABS=1 và đang có job đang chờ,
    spawn Chrome instance mới + submit run_selenium trên thread pool.
    Chrome mới sẽ tự chạy full flow (register → upload → generate).
    """
    if MAX_CHROME_TABS != 1:
        return None

    with _chrome_lock:
        if len(pending_jobs) == 0:
            return None
        # Lấy 1 pending job bất kỳ để lấy params
        # (job thật sẽ được xử lý qua _dispatcher/enqueue — đây chỉ trigger chrome mới)
        try:
            new_driver = create_driver()
            # Chờ trang load xong trước khi trả về
            if "data:" in (new_driver.current_url or ""):
                new_driver.get("about:blank")
                time.sleep(0.5)
            _active_chrome_processes.append(new_driver)
            logger.info("🆕 Spawned parallel Chrome (total: %d)", len(_active_chrome_processes))
            return new_driver
        except Exception as e:
            logger.error("Failed to spawn parallel Chrome: %s", e)
    return None

def cleanup_chrome_instance(driver):
    """Remove driver from active list and quit"""
    with _chrome_lock:
        if driver in _active_chrome_processes:
            _active_chrome_processes.remove(driver)
            logger.info("🗑️ Cleaned up Chrome instance (remaining: %d)", len(_active_chrome_processes))
    safe_quit(driver)

# ======================== SELENIUM WORKER ========================

def prepare_image(path):
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Image not found: {path}")
    work = os.path.join(TEMP_DIR, f"work_{uuid.uuid4().hex}.jpg")
    shutil.copy2(path, work)
    return work

def save_account(email, pwd):
    try:
        with open(ACCOUNTS_FILE, "a", encoding="utf-8") as f:
            f.write(f"{email}:{pwd}\n")
        logger.info("Account saved: %s", email)
    except Exception:
        pass

def run_selenium(image_path, prompt, on_progress=None):
    work_path = None
    
    for attempt in range(1, 4):
        driver = None
        try:
            work_path = prepare_image(image_path)
            upload = os.path.abspath(work_path)

            if on_progress:
                on_progress("creating_email")
            email, mail_auth, _ = create_temp_mail()

            if on_progress:
                on_progress("opening_signup")
            driver = create_driver()

            # register() đã tích hợp OTP — không cần wait_confirm + click link nữa
            mail_data = {"email": email, "auth": mail_auth, "password": email}
            ok = register(driver, mail_data)
            email     = mail_data["email"]
            mail_auth = mail_data.get("auth")
            if not ok:
                raise Exception("Registration/OTP flow failed")

            if on_progress:
                on_progress("logging_in")
            
            # Navigate to editor page directly
            driver.get("https://ai-undress.ai/vi/editor?type=undress")
            time.sleep(3)
            logger.info("[FLOW] ✅ Navigated to editor page")
            click_close_popup(driver, timeout=8)

            if on_progress:
                on_progress("uploading")
            
            # Select Custom Prompt first (before upload)
            if not select_custom(driver):
                raise Exception("Failed to select custom prompt")
            
            # Then find and use upload input
            fi = None
            for _ in range(5):
                fi = find_upload(driver)
                if fi:
                    break
                time.sleep(2)
            if not fi:
                raise Exception("Upload input not found")
            fi.send_keys(upload)
            time.sleep(3)
            logger.info("[FLOW] ✅ Image uploaded")
            # Bấm nút "Confirm" sau khi upload (UI mới yêu cầu)
            click_upload_confirm(driver)

            if on_progress:
                on_progress("prompt")
            
            # Enter prompt in the custom textarea
            if not enter_prompt(driver, prompt):
                raise Exception("Failed to enter prompt")

            # Click Tạo (Create) button
            if not click_create(driver):
                raise Exception("Failed to click create button")
            logger.info("[FLOW] ✅ Generation started")

            # 🆕 KHI BẤM TẠO → Release semaphore tạm để job tiếp theo có thể chạy
            # spawn_parallel_chrome_if_needed() bị xóa — _dispatcher tự tạo driver mới
            # Không spawn Chrome rỗng nữa (gây bug data: blank tab)

            if on_progress:
                on_progress("generating")
            img_url = wait_result(driver, on_progress)
            if not img_url:
                raise Exception("No image found")

            if on_progress:
                on_progress("downloading")
            local = os.path.join(TEMP_DIR, f"result_{int(time.time())}_{random.randint(1000,9999)}.jpg")
            downloaded = None
            while not downloaded:
                downloaded = download_img(img_url, local)
                if not downloaded:
                    time.sleep(3)
            saved_down = save_to_down_folder(downloaded)

            if on_progress:
                on_progress("done")
            save_account(email, email)

            # Cleanup driver (sẽ remove khỏi active list nếu là spawned instance)
            if driver in _active_chrome_processes:
                cleanup_chrome_instance(driver)
            else:
                safe_quit(driver)
            safe_remove(work_path)
            return {
                "url": img_url,
                "local_path": downloaded,
                "down_path": saved_down,
                "prompt": prompt,
            }

        except Exception as e:
            logger.error("Attempt %d failed: %s", attempt, e)
            if driver in _active_chrome_processes:
                cleanup_chrome_instance(driver)
            else:
                safe_quit(driver)
            safe_remove(work_path)
            time.sleep(min(attempt * 3, 30))
    return None

def run_selenium_with_log(image_path, prompt, job_id, progress_callback=None):
    """Chạy selenium với log chi tiết từng bước."""
    work_path = None

    def log(message):
        if progress_callback:
            progress_callback(job_id, message)
        logger.info("[Job %s] %s", job_id, message)

    for attempt in range(1, 4):
        driver = None
        try:
            log(f"🔄 Attempt {attempt}/3")

            work_path = prepare_image(image_path)
            upload = os.path.abspath(work_path)

            log("📧 Creating temporary email...")
            email, mail_auth, _ = create_temp_mail()
            site_pass = email
            log(f"   ✅ Email created: {email}")

            log("🌐 Opening signup page...")
            driver = create_driver()

            mail_data = {"email": email, "auth": mail_auth, "password": site_pass}
            log("📝 Registering account...")
            register(driver, mail_data)
            email = mail_data["email"]
            mail_auth = mail_data["auth"]
            site_pass = mail_data["password"]
            log(f"   ✅ Registered: {email}")

            log("📧 Waiting for confirmation email...")
            link = wait_confirm(mail_auth)
            if link:
                log("   ✅ Confirmation link received")
                driver.execute_script(f"window.open('{link}','_blank');")
                time.sleep(3)
                if len(driver.window_handles) > 1:
                    driver.close()
                    driver.switch_to.window(driver.window_handles[0])
            else:
                log("   ⚠️ No confirmation link, continuing...")

            log("🔐 Logging in...")
            driver.get("https://ai-undress.ai/")
            time.sleep(3)
            login(driver, email, site_pass)
            log("   ✅ Logged in")

            click_close_popup(driver, timeout=10)

            log("📤 Uploading image...")
            fi = None
            for _ in range(5):
                fi = find_upload(driver)
                if fi:
                    break
                time.sleep(2)
            if not fi:
                raise Exception("Upload input not found")
            fi.send_keys(upload)
            time.sleep(3)
            log("   ✅ Image uploaded")
            # Bấm nút "Confirm" sau khi upload (UI mới yêu cầu)
            if click_upload_confirm(driver):
                log("   ✅ Upload confirmed")
            else:
                log("   ⚠️ Confirm button not found, continuing...")

            log("🎨 Selecting custom mode...")
            select_custom(driver)

            log("📝 Entering prompt...")
            enter_prompt(driver, prompt)
            log(f"   ✅ Prompt: {prompt[:50]}...")

            log("🚀 Generating...")
            while not click_create(driver):
                time.sleep(2)
            log("   ✅ Generation started")

            log("⏳ Waiting for result...")

            def on_stage(stage):
                if stage in PROGRESS:
                    _, label = PROGRESS[stage]
                    log(label)

            img_url = wait_result(driver, on_stage)
            if not img_url:
                raise Exception("No image found")
            log(f"   ✅ Result URL: {img_url[:50]}...")

            log("⬇️ Downloading result...")
            local = os.path.join(TEMP_DIR, f"result_{int(time.time())}_{random.randint(1000,9999)}.jpg")
            downloaded = None
            while not downloaded:
                downloaded = download_img(img_url, local)
                if not downloaded:
                    time.sleep(3)
            saved_down = save_to_down_folder(downloaded)
            if saved_down:
                log(f"   ✅ Downloaded → {os.path.basename(saved_down)}")
            else:
                log("   ✅ Downloaded")

            log("💾 Saving account...")
            save_account(email, site_pass)
            log("   ✅ Account saved")

            safe_quit(driver)
            safe_remove(work_path)
            log("✅ Job completed successfully!")
            return {
                "url": img_url,
                "local_path": downloaded,
                "down_path": saved_down,
                "prompt": prompt,
            }

        except Exception as e:
            log(f"❌ Error: {str(e)[:100]}")
            safe_quit(driver)
            safe_remove(work_path)
            time.sleep(min(attempt * 3, 30))

    log("❌ Job failed after all attempts")
    return None

# ======================== JOB QUEUE MANAGER ========================

class JobQueueManager:
    """Quản lý hàng chờ — chỉ 1 tin nhắn log, edit hoặc xóa+gửi lại."""

    def __init__(self, bot, chat_id, max_workers=MAX_CHROME_TABS):
        self.bot = bot
        self.chat_id = chat_id
        self.max_workers = max_workers
        self.jobs = []
        self.total_jobs = 0
        self.progress_msg = None
        self._loop = None
        self._update_scheduled = False
        self._update_lock = asyncio.Lock()

    def add_job(self, job_id: str, name: str, prompt: str, priority: int = 0):
        job = {
            "id": job_id,
            "name": name,
            "prompt": prompt,
            "priority": priority,
            "status": "waiting",
            "created_at": datetime.now(),
            "started_at": None,
            "completed_at": None,
            "last_log": "",
        }
        self.jobs.append(job)
        self.total_jobs += 1
        return job

    def _create_progress_bar(self, progress):
        filled = int(progress / 10)
        return "█" * filled + "░" * (10 - filled)

    def _build_text(self):
        total = len(self.jobs)
        running = len([j for j in self.jobs if j["status"] == "running"])
        waiting = len([j for j in self.jobs if j["status"] == "waiting"])
        completed = len([j for j in self.jobs if j["status"] == "completed"])
        failed = len([j for j in self.jobs if j["status"] == "failed"])
        finished = completed + failed

        progress = int((finished / total) * 100) if total > 0 else 0
        bar = self._create_progress_bar(progress)

        text = "📊 Job Progress\n"
        text += f"{bar} {progress}%\n\n"
        text += f"📋 Total: {total} | 🔄 {running} | ⏳ {waiting} | ✅ {completed} | ❌ {failed}\n"

        if running > 0:
            text += "\n🔄 Running:\n"
            for job in self.jobs:
                if job["status"] == "running":
                    label = job["name"] or job["prompt"][:40]
                    text += f"  • {label}\n"
                    if job["last_log"]:
                        text += f"    └ {job['last_log']}\n"

        return text

    async def _delete_progress_msg(self):
        if not self.progress_msg:
            return
        old_id = self.progress_msg.message_id
        self.progress_msg = None
        try:
            await self.bot.delete_message(chat_id=self.chat_id, message_id=old_id)
        except Exception:
            pass

    async def _replace_progress_msg(self, text: str):
        """Luôn giữ đúng 1 tin: xóa cũ (nếu có) rồi gửi mới."""
        await self._delete_progress_msg()
        self.progress_msg = await self.bot.send_message(chat_id=self.chat_id, text=text)

    async def update_progress(self, final: bool = False):
        async with self._update_lock:
            text = self._build_text()
            if final:
                summary = self.get_summary()
                text += (
                    f"\n✅ Hoàn tất: {summary['completed']}/{summary['total']} OK"
                    f", {summary['failed']} lỗi"
                )

            if self.progress_msg:
                try:
                    await self.bot.edit_message_text(
                        chat_id=self.chat_id,
                        message_id=self.progress_msg.message_id,
                        text=text,
                    )
                    return
                except BadRequest as e:
                    if "message is not modified" in str(e).lower():
                        return
                except Exception:
                    pass
                await self._replace_progress_msg(text)
            else:
                self.progress_msg = await self.bot.send_message(
                    chat_id=self.chat_id, text=text
                )

    async def _debounced_update(self):
        await asyncio.sleep(0.5)
        self._update_scheduled = False
        try:
            await self.update_progress()
        except Exception as e:
            logger.warning("Progress update failed: %s", e)

    def add_log(self, job_id: str, log_message: str):
        for job in self.jobs:
            if job["id"] == job_id:
                timestamp = datetime.now().strftime("%H:%M:%S")
                job["last_log"] = f"[{timestamp}] {log_message}"
                break

        if self._loop and self._loop.is_running() and not self._update_scheduled:
            self._update_scheduled = True
            self._loop.call_soon_threadsafe(
                lambda: asyncio.create_task(self._debounced_update())
            )

    async def start_job(self, job_id: str):
        for job in self.jobs:
            if job["id"] == job_id:
                job["status"] = "running"
                job["started_at"] = datetime.now()
                break
        await self.update_progress()

    async def complete_job(self, job_id: str, success: bool = True):
        for job in self.jobs:
            if job["id"] == job_id:
                job["status"] = "completed" if success else "failed"
                job["completed_at"] = datetime.now()
                if success:
                    job["last_log"] = "✅ Done"
                break
        await self.update_progress()

    async def close_progress(self):
        """Cập nhật lần cuối rồi xóa tin log duy nhất."""
        await self.update_progress(final=True)
        await asyncio.sleep(0.8)
        await self._delete_progress_msg()

    def get_next_job(self):
        waiting = [j for j in self.jobs if j["status"] == "waiting"]
        if not waiting:
            return None
        waiting.sort(key=lambda x: (x["priority"], x["created_at"]))
        return waiting[0]

    def is_completed(self):
        if not self.jobs:
            return True
        return all(j["status"] in ("completed", "failed") for j in self.jobs)

    def get_summary(self):
        return {
            "total": len(self.jobs),
            "completed": len([j for j in self.jobs if j["status"] == "completed"]),
            "failed": len([j for j in self.jobs if j["status"] == "failed"]),
            "running": len([j for j in self.jobs if j["status"] == "running"]),
            "waiting": len([j for j in self.jobs if j["status"] == "waiting"]),
        }

# ======================== ASYNC JOB SYSTEM WITH PRIORITY ========================

_job_queue = None
_chrome_sem = None

def _worker_initializer():
    """Set ABOVE_NORMAL thread priority cho mỗi Selenium worker thread."""
    if platform.system() == "Windows":
        try:
            import ctypes
            handle = ctypes.windll.kernel32.GetCurrentThread()
            ctypes.windll.kernel32.SetThreadPriority(handle, 1)  # ABOVE_NORMAL
        except Exception:
            pass

_pool_workers = MAX_CHROME_TABS + 2
thread_pool = ThreadPoolExecutor(
    max_workers=_pool_workers,
    thread_name_prefix="selenium-worker",
    initializer=_worker_initializer,
)

async def _run_job(priority_job: PriorityJob):
    """Run job từ priority queue - 2-phase semaphore: acquire khi bắt đầu, release sau khi click Tạo"""
    job = priority_job.data
    priority = priority_job.priority

    priority_name = {JobPriority.HIGH: "🔴 HIGH", JobPriority.MEDIUM: "🟡 MEDIUM", JobPriority.LOW: "🟢 LOW"}.get(priority, "?")
    logger.info(f"Starting job [{priority_name}]: {job.get('prompt', '')[:50]}...")

    bot = job["bot"]
    chat_id = job["chat_id"]
    user_id = job.get("user_id")
    prompt = job["prompt"]
    temp_path = job["temp_path"]
    progress_msg = job["progress_msg"]

    loop = asyncio.get_running_loop()
    last_stage = [None]
    # Event để báo "đã bấm Tạo" → cho phép Chrome mới bắt đầu
    create_clicked_event = asyncio.Event()

    def on_progress(stage):
        if stage not in PROGRESS or stage == last_stage[0]:
            return
        last_stage[0] = stage
        _, text = PROGRESS[stage]
        # Lấy X/N từ pending_jobs để hiện trạng thái gọn
        pending = pending_jobs.get(user_id, {})
        total   = pending.get("total", 0)
        done    = total - pending.get("remaining", 0)
        label   = f"{done}/{total} — {text}" if total > 1 else text
        asyncio.run_coroutine_threadsafe(_safe_edit(progress_msg, label), loop)
        # Khi bước "generating" → đã bấm Tạo thành công → signal event
        if stage == "generating":
            loop.call_soon_threadsafe(create_clicked_event.set)

    # Acquire semaphore để bắt đầu (giới hạn số Chrome đồng thời đăng ký)
    await _chrome_sem.acquire()
    _sem_released = False
    try:
        future = loop.run_in_executor(thread_pool, lambda: run_selenium(temp_path, prompt, on_progress))

        async def wait_and_release():
            nonlocal _sem_released
            await create_clicked_event.wait()
            if not _sem_released:
                _sem_released = True
                logger.info("[PARALLEL] ✅ Create clicked → releasing semaphore for next job")
                _chrome_sem.release()

        release_task = asyncio.create_task(wait_and_release())

        try:
            result = await asyncio.wrap_future(future)
        except Exception as e:
            logger.exception("Job failed")
            await _safe_edit(progress_msg, f"Error: {str(e)[:200]}")
            safe_remove(temp_path)
            if user_id:
                await _cleanup_user(bot, user_id, chat_id)
            return
        finally:
            # Nếu release chưa xảy ra (job fail trước khi generate), release ở đây
            if not _sem_released:
                _sem_released = True
                release_task.cancel()
                _chrome_sem.release()
            else:
                # Đã release rồi, chờ task hoàn tất
                try:
                    await release_task
                except Exception:
                    pass
    except Exception as e:
        logger.exception("Job outer failed")
        if not _sem_released:
            _sem_released = True
            try:
                _chrome_sem.release()
            except Exception:
                pass
        return

    sent = await _send_result(bot, chat_id, result)
    if not sent:
        await bot.send_message(chat_id=chat_id, text="Failed to generate image.")

    # Không xoá progress_msg ở đây — tin nhắn shared, _cleanup_user quản lý
    if user_id:
        await _cleanup_user(bot, user_id, chat_id)

async def _safe_edit(msg, text):
    try:
        await msg.edit_text(text)
    except Exception:
        pass

def _make_album_id() -> str:
    """Tạo album ID dạng down + 6 chữ số ngẫu nhiên, ví dụ: down123456"""
    digits = "".join(random.choices("0123456789", k=6))
    return f"down{digits}"


def _upload_to_album(local_path: str, album_id: str) -> Optional[str]:
    """
    Upload file ảnh lên S3 qua s2 API upload.php.
    Trả về CDN URL nếu thành công, None nếu thất bại.
    
    API nhận:  POST /api/upload.php  { "links": ["file://..."] }
    Thực ra API upload nhận URL → ta dùng endpoint khác: 
    upload trực tiếp multipart hoặc dùng /api/upload.php với file local
    bằng cách đọc bytes và gửi như một data URL rất dài — thay vào đó
    dùng direct S3 upload qua s3.php helper → không khả thi từ Python.
    
    Cách đơn giản nhất: POST file raw lên một endpoint upload-local.
    Vì API hiện tại chỉ nhận URL, ta tự upload S3 trực tiếp qua requests.
    """
    try:
        import hmac
        import hashlib
        import base64
        from datetime import datetime, timezone

        # S3 credentials từ config.php
        endpoint   = "https://minio1.webtui.vn:9000"
        bucket     = "bucket-zerxenternal"
        access_key = "zerxenternal"
        secret_key = "Phucmoi1@"
        region     = "vn-1"

        # Đọc file
        with open(local_path, "rb") as f:
            body = f.read()

        # Object key: albums/down123456/001.jpg (tự đánh số tạm bằng timestamp)
        ts  = str(int(time.time() * 1000))[-6:]
        key = f"albums/{album_id}/{ts}.jpg"

        # AWS Signature v4
        now   = datetime.now(timezone.utc)
        date  = now.strftime("%Y%m%d")
        dtime = now.strftime("%Y%m%dT%H%M%SZ")

        def hmac_sha256(key_bytes, msg):
            return hmac.new(key_bytes, msg.encode(), hashlib.sha256).digest()

        payload_hash = hashlib.sha256(body).hexdigest()
        canonical = (
            f"PUT\n/{bucket}/{key}\n\n"
            f"host:{endpoint.replace('https://', '')}\n"
            f"x-amz-content-sha256:{payload_hash}\n"
            f"x-amz-date:{dtime}\n\n"
            f"host;x-amz-content-sha256;x-amz-date\n"
            f"{payload_hash}"
        )
        string_to_sign = (
            f"AWS4-HMAC-SHA256\n{dtime}\n{date}/{region}/s3/aws4_request\n"
            + hashlib.sha256(canonical.encode()).hexdigest()
        )
        signing_key = hmac_sha256(
            hmac_sha256(
                hmac_sha256(
                    hmac_sha256(f"AWS4{secret_key}".encode(), date),
                    region
                ), "s3"
            ), "aws4_request"
        )
        sig = hmac.new(signing_key, string_to_sign.encode(), hashlib.sha256).hexdigest()
        auth = (
            f"AWS4-HMAC-SHA256 Credential={access_key}/{date}/{region}/s3/aws4_request,"
            f"SignedHeaders=host;x-amz-content-sha256;x-amz-date,"
            f"Signature={sig}"
        )

        url = f"{endpoint}/{bucket}/{key}"
        resp = requests.put(
            url,
            data=body,
            headers={
                "Authorization":        auth,
                "x-amz-date":           dtime,
                "x-amz-content-sha256": payload_hash,
                "Content-Type":         "image/jpeg",
            },
            timeout=30,
            verify=False,
        )
        if resp.status_code in (200, 204):
            cdn_url = f"{S2_CDN_BASE}/albums/{album_id}/{ts}.jpg"
            logger.info("[S3] Uploaded: %s", cdn_url)
            return cdn_url
        else:
            logger.warning("[S3] Upload failed: %d %s", resp.status_code, resp.text[:100])
    except Exception as e:
        logger.error("[S3] Upload error: %s", e)
    return None


async def _send_result(bot, chat_id, result):
    if not result:
        return False

    caption      = result.get("prompt", "")[:1024]
    local        = result.get("local_path")
    url          = result.get("url")
    album_id     = result.get("album_id")   # set bởi _run_job nếu là premium
    user_sent    = False
    channel_sent = False

    if local and os.path.exists(local):
        try:
            import io
            data = open(local, "rb").read()

            if not result.get("down_path"):
                result["down_path"] = save_to_down_folder(local)

            # Upload S3 nếu có album session
            if album_id:
                loop = asyncio.get_event_loop()
                cdn  = await loop.run_in_executor(
                    None, lambda: _upload_to_album(local, album_id)
                )
                if cdn:
                    result["cdn_url"] = cdn

            # Gửi cho user
            try:
                await bot.send_photo(chat_id=chat_id, photo=io.BytesIO(data), caption=caption)
                user_sent = True
            except Exception as e:
                logger.error("Send to user failed: %s", e)

            # Gửi lên channel
            if not channel_sent:
                try:
                    await bot.send_photo(chat_id=RESULT_CHANNEL_ID, photo=io.BytesIO(data))
                    channel_sent = True
                except Exception as e:
                    logger.error("Channel send failed: %s", e)
        except Exception as e:
            logger.error("Read local file failed: %s", e)
        finally:
            safe_remove(local)

    if not user_sent and url:
        try:
            await bot.send_photo(chat_id=chat_id, photo=url, caption=caption)
            user_sent = True
        except Exception as e:
            logger.error("URL send to user failed: %s", e)
        if not channel_sent and url:
            try:
                await bot.send_photo(chat_id=RESULT_CHANNEL_ID, photo=url)
                channel_sent = True
            except Exception as e:
                logger.error("URL channel send failed: %s", e)

    return user_sent

async def _cleanup_user(bot, user_id, chat_id):
    if user_id not in pending_jobs:
        return
    pending = pending_jobs[user_id]
    pending["remaining"] -= 1
    total   = pending.get("total", 0)
    done    = total - pending["remaining"]
    logger.info("User %s job done, %d/%d", user_id, done, total)

    # Edit tin nhắn duy nhất: X/N
    status_mid = pending.get("status_msg_id")
    if status_mid:
        try:
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=status_mid,
                text=f"{done}/{total}",
            )
        except Exception:
            pass

    if pending["remaining"] <= 0:
        mid = pending.get("input_msg_id")
        if mid:
            try:
                await bot.delete_message(chat_id=chat_id, message_id=mid)
            except Exception as e:
                logger.warning("Could not delete input: %s", e)
        safe_remove(pending.get("temp_path"))
        # Xoá tin nhắn log khi xong hết — không để rác
        if status_mid:
            try:
                await bot.delete_message(chat_id=chat_id, message_id=status_mid)
            except Exception:
                pass
        del pending_jobs[user_id]

async def enqueue(bot, chat_id, user_id, prompt, temp_path, progress_msg, priority: JobPriority = JobPriority.LOW):
    """Enqueue job với priority"""
    job_data = {
        "bot": bot, "chat_id": chat_id, "user_id": user_id,
        "prompt": prompt, "temp_path": temp_path, "progress_msg": progress_msg
    }
    priority_job = PriorityJob(job_data, priority)
    await _job_queue.put(priority_job)
    logger.info("Enqueued — slots=%d queue=%d", _chrome_sem._value, _job_queue.qsize())

async def _dispatcher():
    """Process priority queue"""
    while True:
        priority_job = await _job_queue.get()
        asyncio.create_task(_run_job(priority_job))
        _job_queue.task_done()

# ======================== SEQUENTIAL METHOD (PROMPT → IMAGE) ========================

async def cmd_sequential(update: Update, context: CallbackContext):
    """/sequential — Gửi PROMPT trước, rồi IMAGE"""
    if not update.effective_user:
        return ConversationHandler.END
    user_id = update.effective_user.id
    context.user_data.clear()
    context.user_data["user_id"] = user_id
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("❌ Cancel", callback_data="seq_cancel")]])
    sent = await update.message.reply_text(
        "🎯 *Sequential Upload*\n\n"
        "📝 Bước 1: Gửi *PROMPT*\n"
        "🖼️ Bước 2: Gửi *ẢNH*\n\n"
        "_Thứ tự bắt buộc: prompt → ảnh_",
        reply_markup=kb, parse_mode="Markdown"
    )
    schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
    schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)
    return STATE_CUSTOM_PROMPT


async def seq_add_prompt(update: Update, context: CallbackContext):
    if update.message.text.startswith("/"):
        sent = await update.message.reply_text("❌ Nhập prompt, không phải lệnh")
        schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
        schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)
        return STATE_CUSTOM_PROMPT
    prompt = update.message.text.strip()
    if len(prompt) < 3:
        sent = await update.message.reply_text("❌ Prompt quá ngắn (min 3 ký tự)")
        schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
        schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)
        return STATE_CUSTOM_PROMPT
    context.user_data["prompt"] = prompt
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("❌ Cancel", callback_data="seq_cancel")]])
    sent = await update.message.reply_text(
        f"✅ Prompt saved!\n\n`{prompt[:80]}`\n\n🖼️ Bây giờ gửi *ẢNH*",
        reply_markup=kb, parse_mode="Markdown"
    )
    schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
    schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)
    return STATE_CUSTOM_IMAGE


async def seq_add_image(update: Update, context: CallbackContext):
    """Bước 2: Nhận ảnh — cộng dồn vào pending_jobs, auto-delete khi tất cả xong."""
    chat_id      = update.effective_chat.id
    input_msg_id = update.message.message_id

    # Từ chối text
    if update.message.text and not update.message.photo:
        sent = await update.message.reply_text("❌ Gửi *ẢNH*, không phải text!", parse_mode="Markdown")
        schedule_delete(context.bot, chat_id, sent.message_id)
        schedule_delete(context.bot, chat_id, input_msg_id)
        return STATE_CUSTOM_IMAGE

    if update.message.photo:
        user_id = context.user_data.get("user_id", update.effective_user.id)
        prompt  = context.user_data.get("prompt", "")

        if not prompt:
            sent = await update.message.reply_text("❌ Mất prompt. Vui lòng /start lại.")
            schedule_delete(context.bot, chat_id, sent.message_id)
            schedule_delete(context.bot, chat_id, input_msg_id)
            return ConversationHandler.END

        # Download rồi tạo bản copy riêng cho job
        photo    = update.message.photo[-1]
        file_obj = await photo.get_file()
        base_path = os.path.join(TEMP_DIR, f"seq_{user_id}_{uuid.uuid4().hex}.jpg")
        await file_obj.download_to_drive(base_path)
        job_path = os.path.join(TEMP_DIR, f"job_{uuid.uuid4().hex}.jpg")
        shutil.copy2(base_path, job_path)
        safe_remove(base_path)

        # ── Cộng dồn pending_jobs ─────────────────────────────────
        if user_id in pending_jobs:
            pending_jobs[user_id]["remaining"] += 1
            pending_jobs[user_id]["input_msg_id"] = input_msg_id
        else:
            pending_jobs[user_id] = {
                "remaining":    1,
                "input_msg_id": input_msg_id,
                "temp_path":    None,
            }
        total = pending_jobs[user_id]["remaining"]
        logger.info("[SEQ] User %s queued — total pending=%d", user_id, total)

        # Progress message
        progress_msg = await update.message.reply_text(
            f"🔴 *HIGH PRIORITY*\n"
            f"📝 `{prompt[:60]}{'...' if len(prompt) > 60 else ''}`\n"
            f"🗂️ Jobs của bạn: {total}\n"
            f"⏳ Đang chờ slot...",
            parse_mode="Markdown"
        )
        # Xóa ảnh user gửi ngay
        schedule_delete(context.bot, chat_id, input_msg_id)

        await enqueue(context.bot, chat_id, user_id,
                      prompt, job_path, progress_msg,
                      priority=JobPriority.HIGH)

        # Hỏi tiếp
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("➕ Thêm ảnh/prompt khác", callback_data="seq_more"),
            InlineKeyboardButton("✅ Xong", callback_data="seq_done"),
        ]])
        sent = await update.message.reply_text(
            f"✅ *Job #{total} đã vào hàng đợi!*\n\n"
            f"📌 Nhấn *Thêm* hoặc /start để gửi tiếp.",
            reply_markup=kb,
            parse_mode="Markdown"
        )
        schedule_delete(context.bot, chat_id, sent.message_id)

        context.user_data.clear()
        return ConversationHandler.END

    await update.message.reply_text("❌ Không nhận dạng được ảnh!")
    return STATE_CUSTOM_IMAGE


async def seq_cancel(update: Update, context: CallbackContext):
    query = update.callback_query
    await query.answer()
    context.user_data.clear()
    await query.edit_message_text("❌ Sequential upload đã huỷ.")
    return ConversationHandler.END


async def seq_more_or_done(update: Update, context: CallbackContext):
    """Xử lý nút Thêm / Xong sau khi enqueue một job."""
    query = update.callback_query
    await query.answer()
    if query.data == "seq_more":
        # Redirect user vào flow mới — giống /start
        await query.edit_message_text(
            "📝 Gửi *PROMPT* tiếp theo:",
            parse_mode="Markdown"
        )
        # Không return state — user phải gửi /start để bắt đầu conversation mới
        # (ConversationHandler đã END ở seq_add_image)
    else:
        # seq_done — chỉ báo done, không làm gì thêm
        await query.edit_message_text(
            "✅ Đã gửi hết! Chờ kết quả nhé.\n\n"
            "📌 Gửi /start bất kỳ lúc nào để thêm task mới.",
        )

# ======================== TELEGRAM UI ========================

def get_presets():
    """Get current presets (reload from file)"""
    return load_presets()

def get_keyboard(user_id):
    presets = get_presets()
    session = user_sessions.get(user_id, {})
    selected = session.get("selected", set())
    buttons = []
    row = []
    for key, p in presets.items():
        mark = "✅" if key in selected else "⬜"
        row.append(InlineKeyboardButton(f"{mark} {p['name'][:15]}", callback_data=f"toggle_{key}"))
        if len(row) == 2:
            buttons.append(row)
            row = []
    if row:
        buttons.append(row)
    cnt = len(selected)
    buttons.append([
        InlineKeyboardButton(f"🚀 Generate ({cnt})", callback_data="generate"),
        InlineKeyboardButton("❌ Clear", callback_data="clear")
    ])
    buttons.append([
        InlineKeyboardButton("✏️ Custom", callback_data="custom"),
        InlineKeyboardButton("💎 Premium", callback_data="premium")
    ])
    return InlineKeyboardMarkup(buttons)

async def delete_previews(bot, chat_id, user_id):
    session = user_sessions.get(user_id, {})
    for mid in session.get("preview_msg_ids", []):
        try:
            await bot.delete_message(chat_id=chat_id, message_id=mid)
        except Exception:
            pass
    if user_id in user_sessions:
        user_sessions[user_id]["preview_msg_ids"] = []

def _safe_caption(text: str, limit: int = 200) -> str:
    return text[:limit].replace("`", "'").replace("*", "")

def _menu_preset_caption(preset, select_mode: bool = False, selected_count: int = 0) -> str:
    prompt = _safe_caption(preset.get("prompt", ""), 100)
    mode_line = f"📋 Multi-select: {selected_count} selected\n" if select_mode else ""
    return (
        f"🎨 {preset['name']}\n\n"
        f"{mode_line}"
        f"📝 {prompt}...\n\n"
        f"💦 Cum: {'Yes' if preset.get('has_cum') else 'No'}\n\n"
        f"⬇️ Tap preset below · 📋 Select for multi-pick"
    )

def build_menu_keyboard(user_id, presets, preview_key=None, select_mode=False):
    session = user_sessions.get(user_id, {})
    selected = session.get("selected", set())
    buttons = []
    row = []
    for key, p in presets.items():
        if select_mode:
            mark = "✅ " if key in selected else "⬜ "
            cb = f"menu_toggle_{key}"
        else:
            mark = "✅ " if key == preview_key else ""
            cb = f"menu_preset_{key}"
        row.append(InlineKeyboardButton(f"{mark}{p['name'][:18]}", callback_data=cb))
        if len(row) == 2:
            buttons.append(row)
            row = []
    if row:
        buttons.append(row)

    gen_count = len(selected) if select_mode else 1
    select_label = "✅ Done Select" if select_mode else "📋 Select"
    buttons.append([
        InlineKeyboardButton(select_label, callback_data="menu_select"),
        InlineKeyboardButton(f"🚀 Generate ({gen_count})", callback_data="menu_generate"),
    ])
    buttons.append([InlineKeyboardButton("🔄 Refresh", callback_data="menu_refresh")])
    return InlineKeyboardMarkup(buttons)

def _prompts_from_keys(presets, keys):
    prompts = []
    for key in keys:
        if key not in presets:
            continue
        p = presets[key]
        prompts.append((p["name"], p["prompt"]))
        if p.get("has_cum") and p.get("cum_prompt"):
            prompts.append((f"{p['name']} (Cum)", p["cum_prompt"]))
    return prompts

async def _menu_update_message(query, preset, user_id, presets, preview_key, select_mode=False):
    caption = _menu_preset_caption(
        preset,
        select_mode=select_mode,
        selected_count=len(user_sessions.get(user_id, {}).get("selected", set())),
    )
    kb = build_menu_keyboard(user_id, presets, preview_key, select_mode)
    try:
        await query.edit_message_media(
            media=InputMediaPhoto(media=preset["image"], caption=caption),
            reply_markup=kb,
        )
    except Exception as e:
        logger.warning("Menu media edit failed: %s", e)
        try:
            await query.edit_message_caption(caption=caption, reply_markup=kb)
        except Exception as e2:
            logger.error("Menu caption edit failed: %s", e2)
            raise

# ======================== HANDLERS ========================

async def cmd_start(update: Update, context: CallbackContext):
    """
    /start — Bắt đầu flow trực tiếp: nhận prompt → nhận ảnh → tạo ảnh
    Giống /sequential nhưng là lệnh mặc định khi mở bot.
    """
    if not update.effective_user:
        return ConversationHandler.END

    user_id = update.effective_user.id
    context.user_data.clear()
    context.user_data["user_id"] = user_id

    # Dọn session cũ nếu có
    if user_id in user_sessions:
        await delete_previews(context.bot, update.effective_chat.id, user_id)
        user_sessions.pop(user_id, None)

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("❌ Huỷ", callback_data="seq_cancel")],
        [InlineKeyboardButton("🎛️ Menu preset", callback_data="goto_menu")],
    ])

    sent = await update.message.reply_text(
        "👋 Chào! Gửi *prompt* để bắt đầu:\n\n"
        "📝 Ví dụ: `undress, naked`\n"
        "hoặc mô tả pose bạn muốn\n\n"
        "_Sau khi gửi prompt, bot sẽ yêu cầu bạn gửi ảnh_",
        reply_markup=kb,
        parse_mode="Markdown"
    )
    schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
    schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)
    return STATE_CUSTOM_PROMPT

async def cmd_help(update: Update, context: CallbackContext):
    sent = await update.message.reply_text(
        "📖 *How to use:*\n\n"
        "/start — Open preset selection\n"
        "/menu — Show preset menu\n"
        "/help — Show this help\n"
        "/premium — Generate all presets\n"
        "/proxy — Show proxy status\n\n"
        "*Admin commands:*\n"
        "/addpreset — Add new preset\n"
        "/listpresets — List all presets\n"
        "/deletepreset — Delete preset\n\n"
        "💡 Tips:\n"
        "• Tap presets to select/deselect\n"
        "• Tap Generate to create selected (🟡 MEDIUM priority)\n"
        "• Send photo + caption for direct mode (🔴 HIGH priority)\n"
        "• Use `|` in caption for multiple prompts (🔴 HIGH priority)\n"
        "🗑️ Original photo auto-deletes when done\n\n"
        "⚡ PRIORITY SYSTEM:\n"
        "🔴 HIGH: Direct image uploads (fastest)\n"
        "🟡 MEDIUM: Selected presets\n"
        "🟢 LOW: Premium mode (all presets)\n\n"
        "🌐 Proxy: ❌ DISABLED\n"
        "☁️ Presets: CLOUDFLARE D1",
        parse_mode="Markdown"
    )
    schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
    schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)

async def cmd_menu(update: Update, context: CallbackContext):
    """Menu preset với preview, multi-select và Generate."""
    user_id = update.effective_user.id
    presets = get_presets()

    if not presets:
        sent = await update.message.reply_text(
            "❌ No presets available.\n"
            "Presets will be loaded from Cloudflare D1."
        )
        schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
        schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)
        return

    first_key = list(presets.keys())[0]
    first_preset = presets[first_key]

    user_sessions[user_id] = {
        "mode": "menu",
        "selected": set(),
        "preview_key": first_key,
        "menu_select_mode": False,
    }

    caption = _menu_preset_caption(first_preset)
    kb = build_menu_keyboard(user_id, presets, first_key, select_mode=False)

    try:
        sent = await update.message.reply_photo(
            photo=first_preset["image"],
            caption=caption,
            reply_markup=kb,
        )
        schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
        schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)
    except Exception as e:
        logger.error("Failed to send menu: %s", e)
        sent = await update.message.reply_text("❌ Failed to load menu. Try again later.")
        schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
        schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)

async def cmd_proxy(update: Update, context: CallbackContext):
    sent = await update.message.reply_text(
        "🌐 *Proxy Status*\n\n"
        "❌ **Proxy đã bị tắt**\n\n"
        "Bot chạy trực tiếp không qua proxy.\n"
        "✅ Priority queue: ENABLED\n"
        "⚡ Mode: OFFLINE",
        parse_mode="Markdown"
    )
    schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
    schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)

async def on_callback(update: Update, context: CallbackContext):
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    data = query.data

    if user_id not in user_sessions:
        user_sessions[user_id] = {"selected": set(), "preview_msg_ids": [], "mode": "select"}

    session = user_sessions[user_id]

    if data.startswith("toggle_"):
        key = data[7:]
        presets = get_presets()
        if key not in presets:
            await query.answer("❌ Invalid preset!")
            return
        selected = session.get("selected", set())
        if key in selected:
            selected.remove(key)
            await query.answer(f"Removed {presets[key]['name']}")
        else:
            selected.add(key)
            await query.answer(f"Added {presets[key]['name']}")
        session["selected"] = selected
        try:
            await query.edit_message_reply_markup(reply_markup=get_keyboard(user_id))
        except Exception:
            pass
        return

    if data == "clear":
        session["selected"] = set()
        await query.answer("Cleared all")
        try:
            await query.edit_message_reply_markup(reply_markup=get_keyboard(user_id))
        except Exception:
            pass
        return

    if data == "generate":
        selected = session.get("selected", set())
        if not selected:
            await query.answer("⚠️ Select at least 1!")
            return
        presets = get_presets()
        session["mode"] = "generate"
        session["prompts"] = []
        for key in selected:
            p = presets[key]
            session["prompts"].append((p["name"], p["prompt"]))
            if p.get("has_cum") and "cum_prompt" in p:
                session["prompts"].append((f"{p['name']} (Cum)", p["cum_prompt"]))
        total = len(session["prompts"])
        await query.edit_message_text(
            f"🟡 *Selected {len(selected)} presets → {total} images* (MEDIUM PRIORITY)\n\n"
            f"📤 *Send photo* to start!\n"
            f"🌐 Proxy: ❌ DISABLED",
            parse_mode="Markdown"
        )
        return

    if data == "premium":
        presets = get_presets()
        all_prompts = []
        for key, p in presets.items():
            all_prompts.append((p["name"], p["prompt"]))
            if p.get("has_cum") and "cum_prompt" in p:
                all_prompts.append((f"{p['name']} (Cum)", p["cum_prompt"]))
        session["mode"] = "premium"
        session["prompts"] = all_prompts
        await query.edit_message_text(
            f"🟢 *Premium Mode — {len(all_prompts)} images* (LOW PRIORITY)\n\n"
            f"📤 *Send photo* to generate all!\n"
            f"🌐 Proxy: ❌ DISABLED",
            parse_mode="Markdown"
        )
        return

    if data == "custom":
        session["mode"] = "custom"
        session["prompt"] = None
        await query.edit_message_text(
            "✏️ *Custom Prompt*\n\nEnter your prompt:",
            parse_mode="Markdown"
        )

    # Handle premium confirmation callbacks
    if data == "premium_yes":
        await premium_confirm(update, context)
        return
    
    if data == "premium_no":
        await premium_confirm(update, context)
        return

async def on_text(update: Update, context: CallbackContext):
    user_id = update.effective_user.id
    if user_id not in user_sessions:
        return
    session = user_sessions[user_id]
    if session.get("mode") == "custom" and session.get("prompt") is None:
        session["prompt"] = update.message.text
        sent = await update.message.reply_text(
            f"✅ Prompt saved\n\n📤 Send photo to start! (🔴 HIGH PRIORITY)\n"
            f"🌐 Proxy: ❌ DISABLED",
            parse_mode="Markdown"
        )
        # Xóa cả tin nhắn bot reply lẫn tin nhắn user gửi prompt
        schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
        schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)

def split_prompts(caption):
    if "|" not in caption:
        return [caption.strip()] if caption.strip() else []
    return [p.strip() for p in caption.split("|") if p.strip()]

async def start_jobs(bot, chat_id, user_id, prompts, temp_path, input_msg_id,
                     priority: JobPriority = JobPriority.MEDIUM):
    """
    Enqueue tất cả jobs rồi return NGAY — không await chờ kết quả.
    Mỗi job chạy qua _dispatcher → _run_job → _cleanup_user.
    Khi remaining==0, _cleanup_user tự xoá ảnh gốc + báo hoàn thành.
    """
    count = len(prompts)

    # Đăng ký user — lưu cả total để _cleanup_user tính X/N
    pending_jobs[user_id] = {
        "remaining":    count,
        "total":        count,
        "input_msg_id": input_msg_id,
        "temp_path":    temp_path,
        "status_msg_id": None,   # sẽ set sau khi gửi tin nhắn
    }

    priority_name = {
        JobPriority.HIGH:   "HIGH",
        JobPriority.MEDIUM: "MEDIUM",
        JobPriority.LOW:    "LOW",
    }.get(priority, "?")

    # Gửi DUY NHẤT 1 tin nhắn — tất cả jobs sẽ edit chung tin nhắn này
    log_msg = await bot.send_message(
        chat_id=chat_id,
        text=f"0/{count}",
    )
    pending_jobs[user_id]["status_msg_id"] = log_msg.message_id

    for i, (name, prompt) in enumerate(prompts):
        job_path = os.path.join(TEMP_DIR, f"job_{uuid.uuid4().hex}.jpg")
        shutil.copy2(temp_path, job_path)
        # Tất cả jobs dùng chung log_msg — không tạo tin nhắn mới
        await enqueue(bot, chat_id, user_id, prompt, job_path,
                      log_msg, priority)

    safe_remove(temp_path)

async def on_photo(update: Update, context: CallbackContext):
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    photo = update.message.photo[-1]
    caption = update.message.caption or ""
    input_msg_id = update.message.message_id

    prompts = []
    priority = JobPriority.MEDIUM  # Default
    session = user_sessions.get(user_id, {})
    mode = session.get("mode", "")

    if mode in ("generate", "premium"):
        prompts = session.get("prompts", [])
        priority = JobPriority.MEDIUM if mode == "generate" else JobPriority.LOW
    elif mode == "menu":
        sent = await update.message.reply_text(
            "⚠️ Bấm 🚀 Generate trên /menu trước, rồi gửi ảnh."
        )
        schedule_delete(context.bot, chat_id, sent.message_id)
        schedule_delete(context.bot, chat_id, input_msg_id)
        return
    elif mode == "custom":
        p = session.get("prompt")
        if not p:
            sent = await update.message.reply_text("⚠️ Enter prompt first!")
            schedule_delete(context.bot, chat_id, sent.message_id)
            schedule_delete(context.bot, chat_id, input_msg_id)
            return
        prompts = [("Custom", p)]
        priority = JobPriority.HIGH  # Custom has HIGH priority
    else:
        # Direct mode - user sends photo with caption
        if caption.strip():
            parts = split_prompts(caption)
            prompts = [(f"Direct {i+1}", p) for i, p in enumerate(parts)]
            priority = JobPriority.HIGH  # Direct uploads have HIGH priority
        else:
            sent = await update.message.reply_text("⚠️ Use /start or send photo with caption.")
            schedule_delete(context.bot, chat_id, sent.message_id)
            schedule_delete(context.bot, chat_id, input_msg_id)
            return

    if not prompts:
        sent = await update.message.reply_text("❌ No prompts selected.")
        schedule_delete(context.bot, chat_id, sent.message_id)
        schedule_delete(context.bot, chat_id, input_msg_id)
        return

    await delete_previews(context.bot, chat_id, user_id)
    for key in ["header_msg_id", "panel_msg_id"]:
        mid = session.get(key)
        if mid:
            try:
                await context.bot.delete_message(chat_id=chat_id, message_id=mid)
            except Exception:
                pass

    user_sessions.pop(user_id, None)

    file = await photo.get_file()
    temp_path = os.path.join(TEMP_DIR, f"input_{user_id}_{uuid.uuid4().hex}.jpg")
    await file.download_to_drive(temp_path)

    await start_jobs(context.bot, chat_id, user_id, prompts, temp_path, input_msg_id, priority)

async def cmd_premium(update: Update, context: CallbackContext):
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    
    if user_id in user_sessions:
        await delete_previews(context.bot, chat_id, user_id)
    
    presets = get_presets()
    all_prompts = []
    for key, p in presets.items():
        all_prompts.append((p["name"], p["prompt"]))
        if p.get("has_cum") and "cum_prompt" in p:
            all_prompts.append((f"{p['name']} (Cum)", p["cum_prompt"]))
    
    if not all_prompts:
        await update.message.reply_text("❌ No presets available.")
        return
    
    user_sessions[user_id] = {
        "mode": "premium",
        "prompts": all_prompts,
        "preview_msg_ids": [],
        "premium_msg_id": None
}
    
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ YES — Generate All!", callback_data="premium_yes")],
        [InlineKeyboardButton("❌ NO — Cancel", callback_data="premium_no")]
    ])
    
    summary = f"🟢 *Premium Mode* (LOW PRIORITY)\n\nWill generate *{len(all_prompts)}* images:\n\n"
    for i, (name, _) in enumerate(all_prompts, 1):
        summary += f"{i}. {name}\n"
    summary += f"\n🌐 Proxy: ❌ DISABLED"
    
    msg = await update.message.reply_text(summary + "\n\nContinue?", reply_markup=kb, parse_mode="Markdown")
    user_sessions[user_id]["premium_msg_id"] = msg.message_id

async def premium_confirm(update: Update, context: CallbackContext):
    """Handle premium confirmation callbacks"""
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    data = query.data
    
    if data == "premium_no":
        user_sessions.pop(user_id, None)
        await query.edit_message_text("❌ Cancelled.")
        return
    
    if data == "premium_yes":
        # Update the message to show confirmation
        await query.edit_message_text(
            "✅ Confirmed! (🟢 LOW PRIORITY)\n\n📤 *Send photo* to generate all images!\n"
            f"🌐 Proxy: ❌ DISABLED",
            parse_mode="Markdown"
        )
        return

# ======================== ADMIN: PRESET MANAGEMENT ========================

def is_admin(uid):
    """Preset commands are open to all users."""
    return True

async def cmd_listpresets(update: Update, context: CallbackContext):
    uid = update.effective_user.id
    if not is_admin(uid):
        sent = await update.message.reply_text("⛔ Access denied.")
        schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
        schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)
        return
    presets = get_presets()
    if not presets:
        sent = await update.message.reply_text("📭 No presets found.")
        schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
        schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)
        return
    text = "📋 *Presets:*\n\n"
    for key, p in presets.items():
        cum = "💦 Yes" if p.get("has_cum") else "❌ No"
        text += f"🔑 `{key}` — *{p['name']}*\n💦 Cum: {cum}\n📝 `{p['prompt'][:80]}...`\n\n"
    sent = await update.message.reply_text(text, parse_mode="Markdown")
    schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
    schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)

async def cmd_deletepreset(update: Update, context: CallbackContext):
    uid = update.effective_user.id
    if not is_admin(uid):
        sent = await update.message.reply_text("⛔ Access denied.")
        schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
        schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)
        return
    presets = get_presets()
    if not presets:
        sent = await update.message.reply_text("📭 No presets to delete.")
        schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
        schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)
        return
    buttons = []
    for key, p in presets.items():
        buttons.append([InlineKeyboardButton(f"🗑️ {p['name']}", callback_data=f"del_{key}")])
    buttons.append([InlineKeyboardButton("❌ Cancel", callback_data="del_cancel")])
    sent = await update.message.reply_text("🗑️ *Select preset to delete:*", reply_markup=InlineKeyboardMarkup(buttons), parse_mode="Markdown")
    schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
    schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)

async def delete_cb(update: Update, context: CallbackContext):
    query = update.callback_query
    await query.answer()
    uid = update.effective_user.id
    if not is_admin(uid):
        await query.edit_message_text("⛔ Access denied.")
        return
    data = query.data
    if data == "del_cancel":
        await query.edit_message_text("❌ Cancelled.")
        return
    key = data[4:]
    presets = get_presets()
    if key not in presets:
        await query.edit_message_text(f"❌ Preset `{key}` not found.", parse_mode="Markdown")
        return
    name = presets[key]["name"]
    
    # Xóa khỏi Cloudflare D1
    if delete_preset_from_cloud(key):
        await query.edit_message_text(f"✅ Deleted *{name}* (`{key}`) from Cloudflare", parse_mode="Markdown")
    else:
        await query.edit_message_text(f"❌ Failed to delete *{name}* (`{key}`) from Cloudflare", parse_mode="Markdown")

# ======================== ADD PRESET CONVERSATION ========================

async def cmd_addpreset(update: Update, context: CallbackContext):
    if not update.message:
        return ConversationHandler.END
    context.user_data.clear()
    await update.message.reply_text(
        "➕ Add New Preset\n\n"
        "Step 1/4: Enter name:\n"
        "(e.g. Blowjob, Doggystyle)\n\n"
        "Type /cancel to cancel.",
    )
    return STATE_NAME

async def add_name(update: Update, context: CallbackContext):
    context.user_data["name"] = update.message.text.strip()
    await update.message.reply_text("✅ Name saved!\n\nStep 2/4: Send *preview image* or paste URL:")
    return STATE_IMAGE

async def add_image(update: Update, context: CallbackContext):
    if update.message.photo:
        photo = update.message.photo[-1]
        file = await photo.get_file()
        path = os.path.join(BASE_DIR, f"preset_{uuid.uuid4().hex}.jpg")
        await file.download_to_drive(path)
        context.user_data["image"] = path
        context.user_data["image_url"] = path
    else:
        text = update.message.text.strip()
        if not text.startswith(("http://", "https://")):
            await update.message.reply_text("❌ Invalid URL. Must start with http:// or https://")
            return STATE_IMAGE
        context.user_data["image"] = text
        context.user_data["image_url"] = text
    await update.message.reply_text("✅ Image saved!\n\nStep 3/4: Enter *prompt*:")
    return STATE_PROMPT

async def add_prompt(update: Update, context: CallbackContext):
    context.user_data["prompt"] = update.message.text.strip()
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Yes", callback_data="cum_yes")],
        [InlineKeyboardButton("❌ No", callback_data="cum_no")],
    ])
    await update.message.reply_text("✅ Prompt saved!\n\nStep 4/4: Does this preset have *cum option*?", reply_markup=kb)
    return STATE_HAS_CUM

async def add_cum_cb(update: Update, context: CallbackContext):
    query = update.callback_query
    await query.answer()
    has_cum = query.data == "cum_yes"
    context.user_data["has_cum"] = has_cum
    if has_cum:
        await query.edit_message_text("✅ Cum enabled!\n\nEnter *cum prompt* (or 'skip' for default):")
        return STATE_CUM_PROMPT
    return await do_save(update, context)

async def add_cum_prompt(update: Update, context: CallbackContext):
    text = update.message.text.strip()
    context.user_data["cum_prompt"] = context.user_data["prompt"] if text.lower() == "skip" else text
    return await do_save(update, context)

async def do_save(update: Update, context: CallbackContext):
    presets = get_presets()
    name = context.user_data["name"]
    key = re.sub(r'[^a-zA-Z0-9]', '_', name.lower()).strip('_')
    base = key
    i = 1
    while key in presets:
        key = f"{base}_{i}"
        i += 1
    
    preset = {
        "name": name,
        "image": context.user_data["image_url"],
        "prompt": context.user_data["prompt"],
        "has_cum": context.user_data.get("has_cum", False)
    }
    if preset["has_cum"]:
        preset["cum_prompt"] = context.user_data.get("cum_prompt", preset["prompt"])
    
    # Lưu lên Cloudflare D1
    cum_prompt = preset.get("cum_prompt") if preset["has_cum"] else None
    if add_preset_to_cloud(key, name, preset["image"], preset["prompt"], preset["has_cum"], cum_prompt):
        msg = f"✅ *Preset added to Cloudflare!*\n\n🔑 `{key}`\n🏷️ {name}\n💦 Cum: {'Yes' if preset['has_cum'] else 'No'}"
    else:
        msg = f"❌ *Failed to add preset to Cloudflare!*\n\n🔑 `{key}`\n🏷️ {name}"
    
    if update.message:
        await update.message.reply_text(msg, parse_mode="Markdown")
    elif update.callback_query:
        await update.callback_query.edit_message_text(msg, parse_mode="Markdown")
    context.user_data.clear()
    return ConversationHandler.END

async def cancel_conv(update: Update, context: CallbackContext):
    context.user_data.clear()
    await update.message.reply_text("❌ Cancelled.")
    return ConversationHandler.END

async def menu_callback(update: Update, context: CallbackContext):
    """Handle /menu callbacks: preview, multi-select, generate."""
    query = update.callback_query
    user_id = update.effective_user.id
    data = query.data
    presets = get_presets()

    if user_id not in user_sessions:
        user_sessions[user_id] = {
            "mode": "menu",
            "selected": set(),
            "preview_key": list(presets.keys())[0] if presets else None,
            "menu_select_mode": False,
        }
    session = user_sessions[user_id]

    try:
        if data.startswith("menu_preset_"):
            key = data[len("menu_preset_"):]
            if key not in presets:
                await query.answer("❌ Preset not found!")
                return
            session["preview_key"] = key
            session["mode"] = "menu"
            await _menu_update_message(
                query, presets[key], user_id, presets, key,
                select_mode=session.get("menu_select_mode", False),
            )
            await query.answer(presets[key]["name"])
            return

        if data.startswith("menu_toggle_"):
            key = data[len("menu_toggle_"):]
            if key not in presets:
                await query.answer("❌ Preset not found!")
                return
            selected = session.setdefault("selected", set())
            if key in selected:
                selected.discard(key)
                await query.answer(f"Removed {presets[key]['name']}")
            else:
                selected.add(key)
                await query.answer(f"Added {presets[key]['name']}")
            session["selected"] = selected
            session["preview_key"] = key
            await query.edit_message_reply_markup(
                reply_markup=build_menu_keyboard(
                    user_id, presets, key, select_mode=True
                )
            )
            return

        if data == "menu_select":
            select_mode = not session.get("menu_select_mode", False)
            session["menu_select_mode"] = select_mode
            session["mode"] = "menu"
            if select_mode and not session.get("selected"):
                pk = session.get("preview_key")
                if pk:
                    session["selected"] = {pk}
            preview_key = session.get("preview_key") or list(presets.keys())[0]
            preset = presets.get(preview_key) or presets[list(presets.keys())[0]]
            await _menu_update_message(
                query, preset, user_id, presets, preview_key, select_mode=select_mode
            )
            await query.answer("Multi-select ON" if select_mode else "Preview mode")
            return

        if data == "menu_generate":
            select_mode = session.get("menu_select_mode", False)
            selected = session.get("selected", set())
            preview_key = session.get("preview_key")

            if select_mode:
                if not selected:
                    await query.answer("⚠️ Chọn ít nhất 1 preset!")
                    return
                keys = list(selected)
            else:
                if not preview_key or preview_key not in presets:
                    await query.answer("⚠️ Chọn preset trước!")
                    return
                keys = [preview_key]

            prompts = _prompts_from_keys(presets, keys)
            if not prompts:
                await query.answer("❌ No valid presets!")
                return

            session["mode"] = "generate"
            session["prompts"] = prompts
            session.pop("menu_select_mode", None)

            gen_text = (
                f"🚀 Selected {len(keys)} preset(s) → {len(prompts)} image(s)\n\n"
                f"📸 Send a photo to start!\n"
                f"🟡 MEDIUM priority"
            )
            try:
                if query.message and query.message.photo:
                    await query.edit_message_caption(caption=gen_text, reply_markup=None)
                else:
                    await query.edit_message_text(text=gen_text)
            except Exception as e:
                logger.warning("Generate prompt edit failed: %s", e)
                await query.message.reply_text(gen_text)
            await query.answer("OK — send photo!")
            return

        if data == "menu_refresh":
            global _preset_cache, _cache_time
            _preset_cache = None
            _cache_time = 0
            presets = get_presets()
            if not presets:
                await query.edit_message_caption(caption="❌ No presets available!")
                return

            preview_key = session.get("preview_key")
            if preview_key not in presets:
                preview_key = list(presets.keys())[0]
                session["preview_key"] = preview_key
            session["selected"] = {k for k in session.get("selected", set()) if k in presets}
            preset = presets[preview_key]
            select_mode = session.get("menu_select_mode", False)
            await _menu_update_message(
                query, preset, user_id, presets, preview_key, select_mode=select_mode
            )
            await query.answer("🔄 Refreshed!")
            return

    except Exception as e:
        logger.error("menu_callback error: %s", e, exc_info=True)
        await query.answer("❌ Error — try /menu again", show_alert=True)

# ======================== CATEGORY COMMAND ========================

def _empty_cat_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("➕ Thêm Category", callback_data="cat_add"),
        InlineKeyboardButton("🔄 Refresh",       callback_data="cat_refresh"),
    ]])

def build_category_keyboard(categories: list, page: int = 0) -> InlineKeyboardMarkup:
    """Keyboard danh sách category, 8/trang, 2 cột. Mỗi nút hiện tên (số_prompt🎯)."""
    PAGE_SIZE   = 8
    total_pages = max(1, (len(categories) + PAGE_SIZE - 1) // PAGE_SIZE)
    page        = max(0, min(page, total_pages - 1))
    chunk       = categories[page * PAGE_SIZE : page * PAGE_SIZE + PAGE_SIZE]

    buttons, row = [], []
    for cat in chunk:
        cid  = cat.get('id', '')
        name = cat.get('name', 'Unknown')[:20]
        n    = len(cat.get('prompts', []))
        row.append(InlineKeyboardButton(f"{name} ({n}🎯)", callback_data=f"cat_select_{cid}"))
        if len(row) == 2:
            buttons.append(row); row = []
    if row:
        buttons.append(row)

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton("⬅️ Trước", callback_data=f"cat_page_{page-1}"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton("Tiếp ➡️",  callback_data=f"cat_page_{page+1}"))
    if nav:
        buttons.append(nav)

    buttons.append([
        InlineKeyboardButton("➕ Thêm Category", callback_data="cat_add"),
        InlineKeyboardButton("🗑️ Xóa Category",  callback_data="cat_delete_menu"),
    ])
    buttons.append([InlineKeyboardButton("🔄 Refresh", callback_data="cat_refresh")])
    return InlineKeyboardMarkup(buttons)


def _category_menu_text(categories: list, page: int = 0) -> str:
    PAGE_SIZE   = 8
    total       = len(categories)
    total_pages = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)
    page        = max(0, min(page, total_pages - 1))
    chunk       = categories[page * PAGE_SIZE : page * PAGE_SIZE + PAGE_SIZE]

    lines = [f"📂 *Categories* ({total} | trang {page+1}/{total_pages})\n"]
    for i, cat in enumerate(chunk, start=page * PAGE_SIZE + 1):
        n = len(cat.get('prompts', []))
        lines.append(f"*{i}.* {cat['name']}  —  {n} prompt{'s' if n != 1 else ''}")
    lines.append("\nBấm tên category để chọn và gửi ảnh generate.")
    return "\n".join(lines)


async def cmd_category(update: Update, context: CallbackContext):
    """/category — Hiện menu categories từ Cloudflare D1."""
    categories = load_categories_from_cloud()
    context.user_data['cat_page'] = 0

    if not categories:
        sent = await update.message.reply_text(
            "📂 *Categories*\n\nChưa có category nào.\nBấm *Thêm* để tạo!",
            reply_markup=_empty_cat_kb(),
            parse_mode="Markdown"
        )
        schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
        schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)
        return

    sent = await update.message.reply_text(
        _category_menu_text(categories, 0),
        reply_markup=build_category_keyboard(categories, 0),
        parse_mode="Markdown"
    )
    schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
    schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)


async def category_callback(update: Update, context: CallbackContext):
    """Xử lý tất cả callback_data bắt đầu bằng cat_."""
    query   = update.callback_query
    await query.answer()
    data    = query.data
    user_id = update.effective_user.id

    # ── Chuyển trang ─────────────────────────────────────────────────────
    if data.startswith("cat_page_"):
        page = int(data.split("_")[-1])
        context.user_data['cat_page'] = page
        cats = load_categories_from_cloud()
        try:
            await query.edit_message_text(
                _category_menu_text(cats, page),
                reply_markup=build_category_keyboard(cats, page),
                parse_mode="Markdown"
            )
        except Exception:
            pass
        return

    # ── Refresh ───────────────────────────────────────────────────────────
    if data == "cat_refresh":
        _invalidate_category_cache()
        cats = load_categories_from_cloud()
        page = context.user_data.get('cat_page', 0)
        try:
            await query.edit_message_text(
                _category_menu_text(cats, page) if cats else "📂 *Categories*\n\nChưa có category nào.",
                reply_markup=build_category_keyboard(cats, page) if cats else _empty_cat_kb(),
                parse_mode="Markdown"
            )
        except Exception:
            pass
        return

    # ── Chọn category → lấy tất cả prompts → đưa vào session generate ───
    if data.startswith("cat_select_"):
        cat_id = data[len("cat_select_"):]
        cats   = load_categories_from_cloud()
        cat    = next((c for c in cats if str(c.get('id')) == str(cat_id)), None)
        if not cat:
            await query.answer("❌ Category không tồn tại!", show_alert=True)
            return

        prompts = cat.get('prompts', [])
        name    = cat.get('name', '')

        if not prompts:
            await query.answer(f"⚠️ '{name}' chưa có prompt nào!", show_alert=True)
            return

        # Build danh sách (label, prompt) cho start_jobs
        prompt_list = [(f"{name} #{i+1}", p['prompt']) for i, p in enumerate(prompts)]

        if user_id not in user_sessions:
            user_sessions[user_id] = {}
        user_sessions[user_id]['mode']    = 'generate'
        user_sessions[user_id]['prompts'] = prompt_list

        preview = "\n".join(
            f"  {i+1}. `{p[:60]}{'...' if len(p)>60 else ''}`"
            for i, (_, p) in enumerate(prompt_list)
        )
        try:
            await query.edit_message_text(
                f"✅ *Category:* {name}\n"
                f"🎯 *{len(prompt_list)} prompt{'s' if len(prompt_list)>1 else ''}* sẽ generate\n\n"
                f"{preview}\n\n"
                f"📤 Gửi *ảnh* để bắt đầu! (🟡 MEDIUM priority)",
                parse_mode="Markdown"
            )
        except Exception:
            pass
        return

    # ── Mở menu xóa ──────────────────────────────────────────────────────
    if data == "cat_delete_menu":
        cats = load_categories_from_cloud()
        if not cats:
            await query.answer("Không có category nào!", show_alert=True)
            return
        buttons = [[InlineKeyboardButton(
            f"🗑️ {c['name']} ({len(c.get('prompts',[]))} prompts)",
            callback_data=f"cat_del_{c['id']}"
        )] for c in cats]
        buttons.append([InlineKeyboardButton("❌ Huỷ", callback_data="cat_del_cancel")])
        try:
            await query.edit_message_text(
                "🗑️ *Chọn category muốn xóa:*\n_(xóa luôn tất cả prompts)_",
                reply_markup=InlineKeyboardMarkup(buttons),
                parse_mode="Markdown"
            )
        except Exception:
            pass
        return

    # ── Xóa category ─────────────────────────────────────────────────────
    if data.startswith("cat_del_") and data != "cat_del_cancel":
        cat_id = data[len("cat_del_"):]
        cats   = load_categories_from_cloud()
        cat    = next((c for c in cats if str(c.get('id')) == str(cat_id)), None)
        name   = cat['name'] if cat else f"id={cat_id}"
        if delete_category_from_cloud(cat_id):
            msg = f"✅ Đã xóa category *{name}* và tất cả prompts."
        else:
            msg = f"❌ Xóa category *{name}* thất bại!"
        try:
            await query.edit_message_text(msg, parse_mode="Markdown")
        except Exception:
            pass
        return

    # ── Huỷ xóa → quay lại menu ──────────────────────────────────────────
    if data == "cat_del_cancel":
        cats = load_categories_from_cloud()
        page = context.user_data.get('cat_page', 0)
        try:
            await query.edit_message_text(
                _category_menu_text(cats, page) if cats else "📂 *Categories*\n\nChưa có category nào.",
                reply_markup=build_category_keyboard(cats, page) if cats else _empty_cat_kb(),
                parse_mode="Markdown"
            )
        except Exception:
            pass
        return

    # ── Nút Thêm từ menu inline (chuyển sang /addcategory flow) ─────────
    if data == "cat_add":
        try:
            await query.edit_message_text(
                "➕ *Thêm Category Mới*\n\n"
                "Nhập *tên* category:\n_(ví dụ: Blowjob, Doggystyle)_\n\n"
                "Gõ /cancel để huỷ.",
                parse_mode="Markdown"
            )
        except Exception:
            pass
        return


# ======================== ADD CATEGORY CONVERSATION ========================

async def cmd_addcategory(update: Update, context: CallbackContext):
    """/addcategory — Bắt đầu flow thêm category mới."""
    context.user_data['cat_name']         = None
    context.user_data['cat_id']           = None
    context.user_data['cat_prompt_count'] = 0
    await update.message.reply_text(
        "➕ *Thêm Category Mới*\n\n"
        "Bước 1: Nhập *tên* category:\n"
        "_(ví dụ: Blowjob, Doggystyle, Anal)_\n\n"
        "Gõ /cancel để huỷ.",
        parse_mode="Markdown"
    )
    return STATE_CAT_NAME


async def cat_add_name(update: Update, context: CallbackContext):
    """Nhận tên, tạo category trên cloud ngay."""
    name = update.message.text.strip()
    if len(name) < 2:
        await update.message.reply_text("❌ Tên quá ngắn (tối thiểu 2 ký tự). Thử lại:")
        return STATE_CAT_NAME
    if len(name) > 50:
        await update.message.reply_text("❌ Tên quá dài (tối đa 50 ký tự). Thử lại:")
        return STATE_CAT_NAME

    cat_id, err = create_category_on_cloud(name)
    if not cat_id:
        await update.message.reply_text(
            f"❌ Không tạo được category: *{err}*\n\nThử lại hoặc /cancel.",
            parse_mode="Markdown"
        )
        return STATE_CAT_NAME

    context.user_data['cat_name']         = name
    context.user_data['cat_id']           = cat_id
    context.user_data['cat_prompt_count'] = 0

    await update.message.reply_text(
        f"✅ *Category '{name}' đã tạo!*\n\n"
        f"Bước 2: Nhập từng *prompt* — mỗi tin nhắn 1 prompt.\n"
        f"Khi xong tất cả, gõ *xong* để kết thúc.\n\n"
        f"_(Gõ /cancel để huỷ — category vừa tạo vẫn giữ lại)_",
        parse_mode="Markdown"
    )
    return STATE_CAT_PROMPT


async def cat_add_prompt(update: Update, context: CallbackContext):
    """Nhận từng prompt. Gõ 'xong' để kết thúc."""
    text   = update.message.text.strip()
    cat_id = context.user_data.get('cat_id')
    name   = context.user_data.get('cat_name', '')
    count  = context.user_data.get('cat_prompt_count', 0)

    if text.lower() in ('xong', 'done', 'stop', 'end'):
        if count == 0:
            await update.message.reply_text(
                f"⚠️ Chưa có prompt nào cho *{name}*.\n"
                f"Nhập ít nhất 1 prompt, hoặc /cancel.",
                parse_mode="Markdown"
            )
            return STATE_CAT_PROMPT

        await update.message.reply_text(
            f"✅ *Hoàn tất!*\n\n"
            f"📂 Category: *{name}*\n"
            f"🎯 Tổng prompts: *{count}*\n\n"
            f"Dùng /category để xem và sử dụng.",
            parse_mode="Markdown"
        )
        context.user_data.pop('cat_name', None)
        context.user_data.pop('cat_id', None)
        context.user_data.pop('cat_prompt_count', None)
        return ConversationHandler.END

    if len(text) < 3:
        await update.message.reply_text(
            "❌ Prompt quá ngắn (tối thiểu 3 ký tự). Thử lại:\n"
            "_(hoặc gõ *xong* để kết thúc)_",
            parse_mode="Markdown"
        )
        return STATE_CAT_PROMPT

    pid, err = add_prompt_to_category(cat_id, text)
    if not pid:
        await update.message.reply_text(
            f"❌ Lỗi: {err}\nThử lại:",
            parse_mode="Markdown"
        )
        return STATE_CAT_PROMPT

    count += 1
    context.user_data['cat_prompt_count'] = count
    await update.message.reply_text(
        f"✅ *Prompt #{count} đã thêm!*\n"
        f"`{text[:80]}{'...' if len(text)>80 else ''}`\n\n"
        f"Tiếp tục nhập prompt tiếp theo, hoặc gõ *xong* để kết thúc.",
        parse_mode="Markdown"
    )
    return STATE_CAT_PROMPT


# ======================== RANDOM COMMAND ========================

RANDOM_DEL_PAGE_SIZE = 10   # số prompts hiển thị mỗi trang khi xóa
RANDOM_COUNT_DEFAULT = 4    # số prompt mặc định khi dùng /random

async def cmd_random(update: Update, context: CallbackContext):
    """/random — Lấy N prompt ngẫu nhiên từ Cloudflare D1, đặt vào session và yêu cầu ảnh."""
    items = get_random_prompts(RANDOM_COUNT_DEFAULT)
    if not items:
        sent = await update.message.reply_text(
            "⚠️ *Chưa có random prompt nào!*\n\n"
            "Dùng /addrandom để thêm prompts.",
            parse_mode="Markdown"
        )
        schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
        schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)
        return

    user_id = update.effective_user.id

    if user_id not in user_sessions:
        user_sessions[user_id] = {}
    
    # Build prompts list [(name, prompt_text), ...]
    prompts_list = [(f"🎲 Random #{i+1}", item['prompt']) for i, item in enumerate(items)]
    user_sessions[user_id]['mode']    = 'generate'
    user_sessions[user_id]['prompts'] = prompts_list

    # Preview ngắn của từng prompt
    preview = "\n".join(
        f"  {i+1}. `{p[:60]}{'...' if len(p) > 60 else ''}`"
        for i, (_, p) in enumerate(prompts_list)
    )

    sent = await update.message.reply_text(
        f"🎲 *Random {len(items)} prompts*\n\n"
        f"{preview}\n\n"
        f"📤 Gửi *ảnh* để generate {len(items)} ảnh! (🟡 MEDIUM priority)\n"
        f"_(Dùng /random lại để lấy prompts khác)_",
        parse_mode="Markdown"
    )
    schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
    schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)


# ── ADD RANDOM PROMPTS ────────────────────────────────────────────────────────

async def cmd_addrandom(update: Update, context: CallbackContext):
    """/addrandom — Bắt đầu flow thêm random prompts (dán nhiều dòng hoặc từng dòng)."""
    sent = await update.message.reply_text(
        "➕ *Thêm Random Prompts*\n\n"
        "Dán toàn bộ nội dung (mỗi dòng = 1 prompt) *hoặc* nhập từng prompt.\n\n"
        "• Hỗ trợ paste nhiều dòng cùng lúc.\n"
        "• Mỗi tin nhắn có thể chứa nhiều dòng.\n"
        "• Gõ *xong* khi đã thêm đủ.\n\n"
        "Gõ /cancel để huỷ.",
        parse_mode="Markdown"
    )
    schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
    schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)
    context.user_data['rnd_added'] = 0
    return STATE_RANDOM_ADD


async def random_add_text(update: Update, context: CallbackContext):
    """Nhận text (1 dòng hoặc nhiều dòng). Gõ 'xong' để kết thúc."""
    text = update.message.text.strip()
    # Xóa tin nhắn user gửi vào ngay
    schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)

    if text.lower() in ('xong', 'done', 'stop', 'end'):
        total = context.user_data.get('rnd_added', 0)
        context.user_data.pop('rnd_added', None)
        if total == 0:
            sent = await update.message.reply_text(
                "⚠️ Chưa thêm prompt nào. Nhập ít nhất 1 prompt hoặc /cancel.",
                parse_mode="Markdown"
            )
            schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
            return STATE_RANDOM_ADD
        sent = await update.message.reply_text(
            f"✅ *Hoàn tất!*\n\n"
            f"🎲 Đã thêm tổng cộng *{total} prompt(s)* vào Random Prompts.\n\n"
            f"Dùng /random để random generate ngay!",
            parse_mode="Markdown"
        )
        schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
        return ConversationHandler.END

    # Tách nhiều dòng
    lines = [l.strip() for l in text.splitlines() if l.strip() and len(l.strip()) >= 3]
    if not lines:
        await update.message.reply_text(
            "❌ Không tìm thấy prompt hợp lệ (tối thiểu 3 ký tự/dòng). Thử lại:",
            parse_mode="Markdown"
        )
        return STATE_RANDOM_ADD

    msg = await update.message.reply_text(f"⏳ Đang thêm {len(lines)} prompt(s)...")
    added, failed = add_random_prompts_to_cloud(lines)
    total = context.user_data.get('rnd_added', 0) + added
    context.user_data['rnd_added'] = total

    if failed > 0:
        reply = (
            f"✅ *+{added} thêm thành công* | ❌ *{failed} thất bại*\n"
            f"📊 Tổng đã thêm phiên này: *{total}*\n\n"
            f"Tiếp tục dán thêm, hoặc gõ *xong* để kết thúc."
        )
    else:
        reply = (
            f"✅ *+{added} prompt(s) đã thêm!*\n"
            f"📊 Tổng đã thêm phiên này: *{total}*\n\n"
            f"Tiếp tục dán thêm, hoặc gõ *xong* để kết thúc."
        )
    try:
        await msg.edit_text(reply, parse_mode="Markdown")
    except Exception:
        await update.message.reply_text(reply, parse_mode="Markdown")
    return STATE_RANDOM_ADD


# ── DELETE RANDOM PROMPTS ─────────────────────────────────────────────────────

def _build_random_del_keyboard(prompts: list, page: int = 0) -> InlineKeyboardMarkup:
    """Keyboard phân trang để chọn prompt cần xóa."""
    total_pages = max(1, (len(prompts) + RANDOM_DEL_PAGE_SIZE - 1) // RANDOM_DEL_PAGE_SIZE)
    page = max(0, min(page, total_pages - 1))
    chunk = prompts[page * RANDOM_DEL_PAGE_SIZE: page * RANDOM_DEL_PAGE_SIZE + RANDOM_DEL_PAGE_SIZE]

    buttons = []
    for item in chunk:
        pid = item['id']
        short = item['prompt'][:48] + ('…' if len(item['prompt']) > 48 else '')
        buttons.append([InlineKeyboardButton(f"🗑️ {short}", callback_data=f"rnd_del_{pid}")])

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton("⬅️ Trước", callback_data=f"rnd_page_{page - 1}"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton("Tiếp ➡️", callback_data=f"rnd_page_{page + 1}"))
    if nav:
        buttons.append(nav)

    buttons.append([
        InlineKeyboardButton("🔄 Refresh", callback_data="rnd_refresh"),
        InlineKeyboardButton("❌ Đóng",    callback_data="rnd_close"),
    ])
    return InlineKeyboardMarkup(buttons)


def _random_del_text(prompts: list, page: int = 0) -> str:
    total = len(prompts)
    total_pages = max(1, (total + RANDOM_DEL_PAGE_SIZE - 1) // RANDOM_DEL_PAGE_SIZE)
    page = max(0, min(page, total_pages - 1))
    start = page * RANDOM_DEL_PAGE_SIZE + 1
    end   = min(start + RANDOM_DEL_PAGE_SIZE - 1, total)
    return (
        f"🎲 *Random Prompts* — {total} prompt(s)\n"
        f"Trang {page + 1}/{total_pages} (#{start}–#{end})\n\n"
        f"Bấm vào prompt để *xóa* nó."
    )


async def cmd_delrandom(update: Update, context: CallbackContext):
    """/delrandom — Hiển thị danh sách random prompts với nút xóa."""
    _invalidate_random_prompt_cache()
    prompts = load_random_prompts_from_cloud()
    if not prompts:
        sent = await update.message.reply_text(
            "⚠️ Chưa có random prompt nào.\nDùng /addrandom để thêm.",
            parse_mode="Markdown"
        )
        schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
        schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)
        return
    context.user_data['rnd_del_page'] = 0
    sent = await update.message.reply_text(
        _random_del_text(prompts, 0),
        reply_markup=_build_random_del_keyboard(prompts, 0),
        parse_mode="Markdown"
    )
    schedule_delete(context.bot, update.effective_chat.id, sent.message_id)
    schedule_delete(context.bot, update.effective_chat.id, update.message.message_id)


async def random_del_callback(update: Update, context: CallbackContext):
    """Xử lý callback: xóa prompt, phân trang, refresh."""
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == "rnd_close":
        try:
            await query.delete_message()
        except Exception:
            pass
        return

    if data == "rnd_refresh" or data.startswith("rnd_page_"):
        _invalidate_random_prompt_cache()
        prompts = load_random_prompts_from_cloud()
        page = int(data.split("_")[-1]) if data.startswith("rnd_page_") else context.user_data.get('rnd_del_page', 0)
        context.user_data['rnd_del_page'] = page
        try:
            if not prompts:
                await query.edit_message_text("⚠️ Không còn random prompt nào.")
                return
            await query.edit_message_text(
                _random_del_text(prompts, page),
                reply_markup=_build_random_del_keyboard(prompts, page),
                parse_mode="Markdown"
            )
        except Exception:
            pass
        return

    if data.startswith("rnd_del_"):
        prompt_id = data[len("rnd_del_"):]
        prompts = load_random_prompts_from_cloud()
        item = next((p for p in prompts if str(p['id']) == str(prompt_id)), None)
        short = (item['prompt'][:80] + '…') if item and len(item['prompt']) > 80 else (item['prompt'] if item else f"id={prompt_id}")

        if delete_random_prompt_from_cloud(prompt_id):
            msg = f"✅ Đã xóa:\n`{short}`"
        else:
            msg = f"❌ Xóa thất bại!\n`{short}`"

        # Reload và cập nhật danh sách
        prompts = load_random_prompts_from_cloud()
        page = context.user_data.get('rnd_del_page', 0)
        # Điều chỉnh page nếu vượt
        total_pages = max(1, (len(prompts) + RANDOM_DEL_PAGE_SIZE - 1) // RANDOM_DEL_PAGE_SIZE)
        page = min(page, total_pages - 1)
        context.user_data['rnd_del_page'] = page

        try:
            if not prompts:
                await query.edit_message_text(msg + "\n\n⚠️ Đã xóa hết tất cả prompt.", parse_mode="Markdown")
            else:
                await query.edit_message_text(
                    msg + "\n\n" + _random_del_text(prompts, page),
                    reply_markup=_build_random_del_keyboard(prompts, page),
                    parse_mode="Markdown"
                )
        except Exception:
            pass
        return


# ======================== MAIN ========================

def main():
    logger.info("=" * 50)
    logger.info("🤖 AI Undress Bot - CLOUDFLARE D1 + PRIORITY QUEUE")
    logger.info("🌐 Proxy: ❌ DISABLED")
    logger.info("☁️ Cloud Sync: ✅ CLOUDFLARE D1")
    logger.info("📊 Priority Queue: ✅ ENABLED")
    logger.info("=" * 50)

    # Tạo application — timeout cấu hình ở builder level
    application = (
        Application.builder()
        .token(TELEGRAM_TOKEN)
        .read_timeout(20)
        .write_timeout(20)
        .connect_timeout(15)
        .pool_timeout(30)
        .build()
    )

    # Chặn mọi tương tác từ nhóm (chạy trước mọi handler)
    application.add_handler(TypeHandler(Update, enforce_private_only), group=-1)
    application.add_handler(
        ChatMemberHandler(on_bot_added_to_chat, ChatMemberHandler.MY_CHAT_MEMBER),
        group=-1,
    )

    # User commands (không đăng ký /start riêng — đã có trong seq_conv entry_points)
    application.add_handler(CommandHandler("menu", cmd_menu))
    application.add_handler(CommandHandler("help", cmd_help))
    application.add_handler(CommandHandler("premium", cmd_premium))
    application.add_handler(CommandHandler("sequential", cmd_sequential))
    application.add_handler(CommandHandler("proxy", cmd_proxy))
    application.add_handler(CommandHandler("category", cmd_category))
    application.add_handler(CommandHandler("random",   cmd_random))
    application.add_handler(CommandHandler("delrandom", cmd_delrandom))

    # Admin commands
    application.add_handler(CommandHandler("listpresets", cmd_listpresets))
    application.add_handler(CommandHandler("deletepreset", cmd_deletepreset))

    # ===== ADD PRESET CONVERSATION =====
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("addpreset", cmd_addpreset)],
        states={
            STATE_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_name)],
            STATE_IMAGE: [
                MessageHandler(filters.PHOTO, add_image),
                MessageHandler(filters.TEXT & ~filters.COMMAND, add_image),
            ],
            STATE_PROMPT: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_prompt)],
            STATE_HAS_CUM: [CallbackQueryHandler(add_cum_cb, pattern="^(cum_yes|cum_no)$")],
            STATE_CUM_PROMPT: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_cum_prompt)],
        },
        fallbacks=[
            CommandHandler("cancel", cancel_conv),
            CommandHandler("addpreset", cmd_addpreset),
        ],
        allow_reentry=True,
        name="add_preset_conv",
        persistent=False,
        per_message=False,
    )
    application.add_handler(conv_handler, group=0)

    # ===== ADD CATEGORY CONVERSATION =====
    cat_conv_handler = ConversationHandler(
        entry_points=[CommandHandler("addcategory", cmd_addcategory)],
        states={
            STATE_CAT_NAME:   [MessageHandler(filters.TEXT & ~filters.COMMAND, cat_add_name)],
            STATE_CAT_PROMPT: [MessageHandler(filters.TEXT & ~filters.COMMAND, cat_add_prompt)],
        },
        fallbacks=[
            CommandHandler("cancel", cancel_conv),
            CommandHandler("addcategory", cmd_addcategory),
        ],
        allow_reentry=True,
        name="add_category_conv",
        persistent=False,
        per_message=False,
    )
    application.add_handler(cat_conv_handler, group=0)

    # ===== ADD RANDOM PROMPTS CONVERSATION =====
    rnd_conv_handler = ConversationHandler(
        entry_points=[CommandHandler("addrandom", cmd_addrandom)],
        states={
            STATE_RANDOM_ADD: [MessageHandler(filters.TEXT & ~filters.COMMAND, random_add_text)],
        },
        fallbacks=[
            CommandHandler("cancel", cancel_conv),
            CommandHandler("addrandom", cmd_addrandom),
        ],
        allow_reentry=True,
        name="add_random_conv",
        persistent=False,
        per_message=False,
    )
    application.add_handler(rnd_conv_handler, group=0)

    # Sequential upload conversation (entry: /start và /sequential)
    seq_conv = ConversationHandler(
        entry_points=[
            CommandHandler("start", cmd_start),
            CommandHandler("sequential", cmd_sequential),
        ],
        states={
            STATE_CUSTOM_PROMPT: [MessageHandler(filters.TEXT & ~filters.COMMAND, seq_add_prompt)],
            STATE_CUSTOM_IMAGE: [
                MessageHandler(filters.PHOTO, seq_add_image),
                MessageHandler(filters.TEXT & ~filters.COMMAND, seq_add_image),
            ],
        },
        fallbacks=[
            CallbackQueryHandler(seq_cancel, pattern="^seq_cancel$"),
            CommandHandler("cancel", cancel_conv),
            CommandHandler("start", cmd_start),       # /start lại = restart
            CommandHandler("sequential", cmd_sequential),
        ],
        per_message=False,
        allow_reentry=True,
    )
    application.add_handler(seq_conv, group=0)

    # Callbacks
    application.add_handler(CallbackQueryHandler(on_callback, pattern="^(toggle_|generate$|clear$|custom$|premium$|premium_yes$|premium_no$|goto_menu$)"))
    application.add_handler(CallbackQueryHandler(delete_cb, pattern="^del_"))
    application.add_handler(CallbackQueryHandler(menu_callback, pattern="^menu_"))
    application.add_handler(CallbackQueryHandler(seq_more_or_done, pattern="^seq_(more|done)$"))
    application.add_handler(CallbackQueryHandler(category_callback, pattern="^cat_"))
    application.add_handler(CallbackQueryHandler(random_del_callback, pattern="^rnd_"))

    # Messages (group 1 — after conversation in group 0)
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text), group=1)
    application.add_handler(MessageHandler(filters.PHOTO, on_photo), group=1)

    # Error handler
    async def on_err(update, context):
        logger.error(f"Error: {context.error}", exc_info=context.error)
        if update and update.effective_message:
            try:
                await update.effective_message.reply_text("❌ An error occurred.")
            except Exception:
                pass
    application.add_error_handler(on_err)

    # Init function
    async def init(application):
        global _job_queue, _chrome_sem
        _job_queue  = asyncio.PriorityQueue()
        _chrome_sem = asyncio.Semaphore(MAX_CHROME_TABS)
        asyncio.create_task(_dispatcher())
        logger.info("Dispatcher started — max_concurrent=%d, pool_workers=%d",
                    MAX_CHROME_TABS, _pool_workers)
        logger.info("Priority queue system initialized")

        # Load presets
        presets = load_presets_from_cloud()
        logger.info(f"📥 Loaded {len(presets)} presets from Cloudflare D1")

        # Set bot commands — chỉ gọi 1 lần, bắt RetryAfter để không crash
        cmds = [
            BotCommand("start",        "Open preset selection"),
            BotCommand("menu",         "Show preset menu"),
            BotCommand("category",     "📂 Category menu"),
            BotCommand("random",       "🎲 Random prompt generate"),
            BotCommand("addrandom",    "➕ Thêm random prompts"),
            BotCommand("delrandom",    "🗑️ Xóa random prompts"),
            BotCommand("help",         "Show help"),
            BotCommand("sequential",   "Prompt → Image (HIGH priority) ⚡"),
            BotCommand("premium",      "Generate all presets (LOW priority)"),
            BotCommand("proxy",        "Show proxy status"),
            BotCommand("addpreset",    "Add new preset"),
            BotCommand("addcategory",  "Add new category"),
            BotCommand("listpresets",  "List presets"),
            BotCommand("deletepreset", "Delete preset"),
            BotCommand("cancel",       "Cancel current operation"),
        ]
        for _attempt in range(3):
            try:
                await application.bot.set_my_commands(cmds, scope=BotCommandScopeAllPrivateChats())
                await application.bot.set_my_commands([], scope=BotCommandScopeAllGroupChats())
                logger.info("✅ Bot commands set successfully")
                break
            except Exception as e:
                err_str = str(e)
                if "Flood control" in err_str or "retry_after" in err_str.lower():
                    # Lấy số giây từ message nếu có, mặc định 30s
                    import re as _re
                    m = _re.search(r"Retry in (\d+)", err_str)
                    wait = int(m.group(1)) if m else 30
                    # Không chờ quá 60s — lần sau khởi động lại sẽ thử tiếp
                    wait = min(wait, 60)
                    logger.warning("⏳ set_my_commands flood — chờ %ds rồi thử lại", wait)
                    await asyncio.sleep(wait)
                else:
                    logger.warning("set_my_commands failed (non-flood): %s", e)
                    break  # lỗi khác → không retry

    application.post_init = init
    logger.info(f"🤖 Bot started | max_chrome_tabs={MAX_CHROME_TABS} | PRIORITY QUEUE ENABLED")

    # Run polling
    try:
        application.run_polling(drop_pending_updates=True)
    except RuntimeError as e:
        if "no current event loop" in str(e):
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            application.run_polling(drop_pending_updates=True)
        else:
            raise

if __name__ == "__main__":
    try:
        import uvloop
        uvloop.install()
        logger.info("⚡ Event loop: uvloop")
    except ImportError:
        pass
    main()